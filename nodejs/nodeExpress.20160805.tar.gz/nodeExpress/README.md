## (2016/08/02)

	search
	
	create table todo (
		id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
		task varchar(30) not null,
		startDate datetime not null,
		endDate datetime,
		type varchar(40)
	)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

## (2016/07/29)

	create table file (
		id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
		name varchar(30) not null,
		date datetime not null,
		address varchar(100) not null,
		password varchar(20) not null
	)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

## (2016/07/28)
	
	create table ID (
		id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
		name varchar(10) not null default '',
		phone int(11),
		birthday DATETIME,
		address varchar(200),
		type tinyint(2)
	)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

## (2016/07/22)MySQL��� / QQ

	���������
	
	tar -zcvf - nodeExpress/ --exclude=node_modules --exclude=dist|openssl des3 -salt -k xxxxx| dd of=nodeExpress.20160722.tar
	dd if=nodeExpress.20160729.tar |openssl des3 -d -k xxxxx|tar zxf -

	*Rx.DOM.ajax post������body��Ҫ�����ַ�������Ҫ����headers: {'Content-Type': 'application/json'}, �������ݲ��ܴ�����̨.*

	// ɾ�����
	ALTER TABLE `password` DROP FOREIGN KEY `id_check`;
	ALTER TABLE password DROP FOREIGN KEY `id_check`;// ����ɾ�����
	ALTER TABLE `password` ADD CONSTRAINT `id_check` FOREIGN KEY (`category`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
	
	
	create table QQ (
		id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
		qq int(11) NOT NULL,
		password varchar(45) NOT NULL
	)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

## (2016/07/20)dialog


## (2016/07/19)font awesome

����������ش���
	
webpack.config.js���ӣ�

```
{
	test: /\.(eot|svg|ttf|woff(2)?)(\?v=\d+\.\d+\.\d+)?/,
	loader: 'url'
}
```
	
���뷽����`@import "~font-awesome/css/font-awesome.css"`
	

## (2016/07/18)category

	create table category (
		id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
		date DATETIME NOT NULL,
		name varchar(45) NOT NULL
	)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
	
	set foreign_key_checks = 0;
	alter table tableName add constraint key_name foreign key(id) references category(id) on
	delete cascade on update cascade;
	
	
	alter table password add constraint id_check foreign key(category) references category(id) on
	delete cascade on update cascade;
	
	set foreign_key_checks = 1;
	// ������foreign_key_checks�ᱨ��
	
	// ɾ�����
	ALTER TABLE `password` DROP FOREIGN KEY `id_check`;

## (2016/07/01)database

	create mysql pool,
	create mysql table: password
	create table password (
		id int(11) PRIMARY KEY NOT; NULL AUTO_INCREMENT,
		date DATETIME NOT NULL,
		name varchar(45) NOT NULL,
		pw_str varchar(200) NOT NULL
	)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 
	
	create table password (
		id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
		date DATETIME NOT NULL,
		netName varchar(45) NOT NULL,
		url varchar(100) NOT NULL,
		register varchar(45) NOT NULL,
		password varchar(20) NOT NULL
	)ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
	
## (2016/06/23)ע���ʽ

how to save chunkhash into file after webpack?

```
/**
 * Build Date: 2016/06/23 09:49.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description:
 */
```

## (2016/06/22)��node��ʹ��es6

```
{
  "dependencies": {
    "babel-cli": "^6.0.0",
    "babel-preset-es2015": "^6.0.0"
  },
  "scripts": {
    "start": "babel-node --presets es2015 ./app.js"
  }
}

npm start;// run node project with this line.
```

package:

- morgin: HTTP request logger middleware for node.js