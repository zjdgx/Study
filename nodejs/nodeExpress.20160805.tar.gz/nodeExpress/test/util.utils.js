/**
 * Build Date: 2016/07/04 15:07.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description: utils test
 */
 
'use strict';

var crypto = require('crypto');

var privateKey = "xcjv'prp,cbp'tcv,wrgdsrl;l,;'p[eazx@!#$!@LLJAL";

let cipher = crypto.createCipher('desx', privateKey),
		result = cipher.update('zzz', 'utf8', 'hex');
		
	result += cipher.final('hex');

console.log(result.length);