'use strict';

import express from 'express';
import appRoutes from './config/route';
import bodyParser from 'body-parser';

const app = express(),
		port = 8000;
		
app.set('view engine', 'jade');
app.set('views', './views');

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())
app.use(express.static(__dirname + '/dist'));

appRoutes.route.forEach((item) => {
	const controller = require(item.path);

	app[item.type](item.url, (req, res, next) => {
		controller[item.method](req, res, next);
	});
});

app.listen(port, () => {
	console.log(`project listen on port: ${port}`);
});