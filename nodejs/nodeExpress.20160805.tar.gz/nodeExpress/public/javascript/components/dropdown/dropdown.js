/**
 * Author: ZJDGX
 * Date: 2016/04/18
 * Description: react drop down
 * Usage: <Dropdown options={} onSelected={}/>
 */
 
import React from 'react';

require('./dropdown.styl');

export default class Dropdown extends React.Component {
	constructor (props) {
		super(props);
		this.state = {
			isOpen: false,
			options: props.options,
			curOption: props.defaultOption || 0
		};
	};
	
	componentWillReceiveProps (props) {
		this.setState({
			options: props.options
		});
	};
	
	handleClickOutside () {
		this.setState({isOpen: false});
	};
	
	onSelected (index) {
		this.setState({
			curOption: index,
			isOpen: false
		}, () => {
			this.props.onSelected && this.props.onSelected(this.props.options[index].key);
		});
	};
	
	toggleOpen () {
		this.setState({isOpen: !this.state.isOpen});
	};
	
	render () {
		return (
			<div className='zjdgx-dropdown'>
				<label 
					className='dropdown-label'
					onClick={this.toggleOpen.bind(this)}>
						{this.state.options[this.state.curOption].value}
				</label>
				<ul className={'dropdown-option-list' + (this.state.isOpen ? '' : ' hide')}>
				{
					this.state.options.map((option, index) => {
						return <li key={index}
									className={this.state.curOption == index ? 'option cur' : 'option'}
									onClick={this.onSelected.bind(this, index)}>
									{option.value}
								</li>;
					})
				}
				{this.props.children}
				</ul>
			</div>
		);
	};
}