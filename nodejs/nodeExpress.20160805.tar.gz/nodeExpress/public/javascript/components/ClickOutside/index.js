import OutsideClick from './OutsideClick';

export default OutsideClick;