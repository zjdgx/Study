/**
 * Build Date: 2016/07/15 16:04.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description: search input component
 */
'use strict';

import React from 'react';

require('./SearchInput.styl');

export default class SearchInput extends React.Component {
	constructor (props) {
		super(props);
		this.state = {
			focus: false
		}
	};
	
	static propTypes = {
		onSearch: React.PropTypes.func.isRequired
	};
	
	onKeyDown (e) {
		if (e.keyCode == 13) {
			e.nativeEvent.preventDefault();
			this.props.onSearch(this.refs['search-input'].value);
		}
	};
	
	render () {
		return (
			<div className={'search-input' + (this.state.focus ? ' search-input_focus' : '')}>
				<i className='fa fa-search'></i>
				<input type='text' ref='search-input'
					onFocus={() => this.setState({focus: true})}
					onBlur={() => this.setState({focus: false})}
					onKeyDown={this.onKeyDown.bind(this)}/>
			</div>
		);
	};
}