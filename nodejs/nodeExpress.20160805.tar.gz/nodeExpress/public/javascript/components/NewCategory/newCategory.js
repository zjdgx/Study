/**
 * Build Date: 2016/07/22 16:42.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description: 
 * 	new category dialog.
 */
'use strict';

import Rx from 'rx-dom'
import React from 'react';

import Dialog from '../Dialog';

export default class NewCategory extends React.Component {
	constructor (props) {
		super(props);
		this.state = {
			name: '',
			showCreateCategoryDialog: props.showCreateCategoryDialog
		};
	};
	
	componentWillReceiveProps (props) {
		// 设置弹出框是否显示
		this.setState({
			showCreateCategoryDialog: props.showCreateCategoryDialog
		});
	};
	
	onChange (e) {
		if (e.keyCode != 13) {
			this.setState({
				name: e.target.value.replace(/^\s+|\s+$/g, '')
			});
		} else {
			this.onSaveCategory('save');
		}
	};
	
	onSaveCategory (type) {
		if (type == 'save') {
			if (this.state.name.length) {
				Rx.DOM.ajax({
					url: '/category/add',
					method: 'POST',
					headers: {
						'Content-type': 'application/json'
					},
					body: JSON.stringify({name: this.state.name})
				})
				.subscribe(
					(data) => {
						console.log('添加分类成功...');
						this.props.toggleCreateDialog('category', data.response);
					},
					(err) => {
						console.log('添加分类失败...');
					}
				);
			}
		} else {
			this.props.toggleCreateDialog();
		}
	};
	
	render () {
		return (
			<Dialog 
				type='dialog'
				title='New Category'
				sureText='保存'
				className={'category-add-dialog' + (this.state.showCreateCategoryDialog ? '' : ' hide')}
				onSure={this.onSaveCategory.bind(this, 'save')}
				onCancel={this.onSaveCategory.bind(this, 'cancel')}
			>
				<input type='text' ref='new-category'
					onChange={this.onChange.bind(this)} />
			</Dialog>
		)
	};
}