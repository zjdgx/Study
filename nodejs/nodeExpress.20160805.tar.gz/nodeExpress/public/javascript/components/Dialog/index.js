/**
 * Build Date: 2016/07/14 14:25.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description: dialog components
 */
'use strict';

import React from 'react';
import ReactDOM from 'react-dom';

require('./dialog.styl');

export default class Dialog extends React.Component {
	constructor (props) {
		super(props);
	};
	
	static defaultProps = {
		onSure: React.PropTypes.func.isRequired,
		onCancel: React.PropTypes.func.isRequired
	};
	
	onSure () {
		this.props.onSure();
	};
	
	onCancel () {
		this.props.onCancel();
	};
	
	saveClose () {
		this.props.onSaveAndClose();
	};
	
	render () {
		return <div ref='dialog' className={`dialog ${this.props.className}`}>
				<div className='row'>
					<div className='cell'>
						<div className='content'>
							<div className='dialog-title'>
								<span>{this.props.title || '提示'}</span>
								<i className='fa fa-dialog-close'
									onClick={this.onCancel.bind(this)}>&times;</i>
							</div>
							<div className='dialog-main'>
								{this.props.children}
							</div>
							<div className='btn-groups'>
								<button className='sure btn btn-primary'
									onClick={this.onSure.bind(this)}>{this.props.sureText || '确定'}</button>
								{
									(() => {
										if (this.props.onSaveAndClose) {
											return <button className='save-close btn btn-primary'
														onClick={this.saveClose.bind(this)}>
														保存并关闭</button>
										}
									})()
								}
								<button className='cancel btn btn-default'
									onClick={this.onCancel.bind(this)}>{this.props.cancelText || '取消'}</button>
							</div>
						</div>
					</div>
				</div>
			</div>
	};
}