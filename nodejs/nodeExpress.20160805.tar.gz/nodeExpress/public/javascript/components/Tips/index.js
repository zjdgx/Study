/**
 * Build Date: 2016/08/03 17:29.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description: tip component
 */
 
'use strict';

import React from 'react';

require('./tips.styl');

export default class Tips extends React.Component {
	constructor (props) {
		super(props);
		this.state = {
			timeout: 5 || props.timeout,
			showMessage: false || props.showMessage
		};
	};
	
	componentDidMount () {
		this.timmer = setTimeout(() => {
			this.setState({
				showMessage: false
			});
		}, this.state.timeout * 1000)
	}
	
	render () {
		return (
			<div className={'tip-content-container' + (this.state.showMessage ? '' : ' hide')}>
			{
				(() => {
					if (this.state.showMessage) {
						return (
							<div className='zjdgx-tip'>
							{this.props.children}
							</div>
						);
					} else {
						return '';
					}
				})()
			}
			</div>
		);
	};
}