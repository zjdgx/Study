/**
 * Build Date: 16/7/26 10:45.
 * Copyright (c): NHN China Co.,LTD
 * Author: ZJDGX
 * Description:
 *	delete dialog of password
 */
 
'use strict';

import Rx from 'rx-dom';
import React from 'react';

import Dialog from '../Dialog';

export default class DeleteDialog extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			type: props.type,
			showDeleteDialog: props.showDeleteDialog
		};
	};
	
	componentWillReceiveProps (props) {
		// 设置弹出框是否显示
		this.setState({
			showDeleteDialog: props.showDeleteDialog
		});
	};
	
	static propTypes = {
		id: React.PropTypes.number.isRequired,
		name: React.PropTypes.string.isRequired,
		type: React.PropTypes.number.isRequired,
		onDelete: React.PropTypes.func.isRequired,
		showDeleteDialog: React.PropTypes.bool.isRequired
	};
	
	deleteItem (type) {
		if ('sure' === type) {
			Rx.DOM.ajax({
				url: `/secret/${this.props.type}/${this.props.id}`,
				method: 'DELETE'
			})
			.subscribe(
				(response) => {
					console.log(`删除${this.props.name}成功`);
					this.props.onDelete(this.props.id, true);
				},
				(err) => {
					console.log(`删除${this.props.name}失败`);
					this.props.onDelete(this.props.id, false);
				}
			)
		} else {
			this.props.onDelete(this.props.id, false);
		}
	};
	
	render () {
		return (
			<Dialog 
				className={'secret-delete-dialog' + (this.state.showDeleteDialog ? '' : ' hide')}
				onSure={this.deleteItem.bind(this, 'sure')}
				onCancel={this.deleteItem.bind(this, 'cancel')}>
				<span>{`确定要删除"${this.props.name}"吗?`}</span>
			</Dialog>
		);
	};
}