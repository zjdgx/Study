/**
 * Build Date: 2016/07/28 17:24.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description:
 *	main entry for secret.
 */
 
'use strict';

import Rx from 'rx-dom';
import React from 'react';
import ReactDOM from 'react-dom';

import QQ from './pages/QQ/qq';
import File from './pages/file/file';
import Tips from './components/Tips';
import Password from './pages/password/password';
import SearchInput from './components/SearchInput';
import ClickOutside from './components/ClickOutside';
import Dropdown from './components/dropdown/dropdown';
import DeleteDialog from './components/DeleteDialog/DeleteDialog';

export default class Secret extends React.Component {
	constructor (props) {
		super(props);

		this.state = {
			// 默认显示第一个, 默认设置为空
			type: {
				key: '',
				value: ''
			},
			// 搜索关键字
			searchKey: '',
			// 默认显示说略同
			viewType: 'thumbnail',
			// 默认不显示下拉列表
			showDropdown: false,
			showCreateDialog: false,
			showDeleteDialog: false,
			deleteItem: {
				id: -1,
				name: '',
				type: -1
			},
			deleteCallback: () => {
			}
		};
	};
	
	componentWillMount () {
		Rx.DOM.ajax({
			method: 'GET',
			url: '/category',
			responseType: 'json'
		})
		.subscribe(
			(data) => {
				this.setState({
					category: data.response,
					type: Object.assign({}, data.response[0])
				})
			},
			(err) => {
				console.log(JSON.stringify(err));
			}
		);
	};
	 
	onSearch (value) {
		this.setState({
			searchKey: value
		});
	};
	
	toggleCreateDialog () {
		this.setState({
			showCreateDialog: !this.state.showCreateDialog
		});
	};
	
	changeCategory (type) {
		this.setState({
			type: this.state.category.find( (item, index) => {
				return item.key === type;
			}),
			showDropdown: false
		});
	};
	
	deleteRecord (params, onDelete) {
		this.setState({
			showDeleteDialog: true,
			deleteItem: {
				id: params.id,
				type: params.type,
				name: params.name
			},
			deleteCallback: onDelete
		});
	};
	
	onDelete (success) {
		this.setState({
			showDeleteDialog: false,
			deleteItem: {
				id: -1,
				name: '',
				type: -1
			}
		}, () => {
			this.state.deleteCallback(success);
		})
	};
	
	saveData (type, params, cb) {
		Rx.DOM.ajax({
			url: params.id ? `/secret/${type}/${params.id}` : `/secret/${type}/add`,
			method: params.id ? 'PUT' : 'POST',
			// headers参数也是必须的
			headers: {
				'Content-Type': 'application/json'
			},
			// 此处必须传入字符串, 否则参数不能传到后台
			body: JSON.stringify(params)
		})
		.subscribe(
			(data) => {
				cb && cb();
			},
			(err) => {
				console.log(err);
			}
		);
	};
	
	//TODO: test tip(2016/08/03)
	showTip () {
		ReactDOM.render(
			<Tips>测试</Tips>,
			this.refs['tip-container']
		);
	};
	 
	render () {
		//<li className='option new-category'	onClick={this.showCreateCategoryDialog.bind(this)}>新建分类</li>
		
		//<i className='fa fa-th-large' onClick={() => this.setState({viewType: 'thumbnail'})}></i>
		
		return (
			<div className='secret'>
				<div className='options'>
					<SearchInput onSearch={this.onSearch.bind(this)} />
					<div className='btn-groups'>
						<i className='fa fa-plus'
							onClick={this.toggleCreateDialog.bind(this)}></i>
						<i className='fa fa-th-large' onClick={this.showTip.bind(this)}></i>
						<i className='fa fa-list' onClick={() => this.setState({viewType: 'list'})}></i>
						{
							(() => {
								if (this.state.category && this.state.category.length) {
									return <Dropdown 
										options={this.state.category}
										isOpen={this.state.showDropdown}
										onSelected={this.changeCategory.bind(this)}>
									</Dropdown>
								}
							})()
						}
					</div>
				</div>
				{
					(() => {
						if (this.state.type.value === 'net') {// net
							return <Password
										type={this.state.type.key}
										searchKey={this.state.searchKey}
										showCreateDialog={this.state.showCreateDialog}
										toggleCreateDialog={this.toggleCreateDialog.bind(this)}
										deleteRecord={this.deleteRecord.bind(this)}
										saveData={this.saveData.bind(this)}/>;
						} else if (this.state.type.value == 'qq') {// QQ
							return <QQ
										type={this.state.type.key}
										searchKey={this.state.searchKey}
										showCreateDialog={this.state.showCreateDialog}
										toggleCreateDialog={this.toggleCreateDialog.bind(this)}
										deleteRecord={this.deleteRecord.bind(this)}
										saveData={this.saveData.bind(this)}/>;
						} else if (this.state.type.value == 'file') {// file
							return <File
										type={this.state.type.key}
										searchKey={this.state.searchKey}
										showCreateDialog={this.state.showCreateDialog}
										toggleCreateDialog={this.toggleCreateDialog.bind(this)}
										deleteRecord={this.deleteRecord.bind(this)}
										saveData={this.saveData.bind(this)}/>;
						} else {
							return <div>Updating...</div>;
						}
					})()
				}
				<DeleteDialog
					id={this.state.deleteItem.id}
					type={this.state.type}
					name={this.state.deleteItem.name}
					onDelete={this.onDelete.bind(this)}
					showDeleteDialog={this.state.showDeleteDialog}/>
				<div ref='tip-container'></div>
			</div>
		);
	}
 }