/**
 * Build Date: 2016/06/23 11:31.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description: net password
 */
'use strict';

import $ from 'jquery';
import Rx from 'rx-dom';
import React from 'react';
import ReactDOM from 'react-dom';

import Util from '../../utils';
import Dialog from '../../components/Dialog';
import PasswordForm from './components/newPassword';
import SearchInput from '../../components/SearchInput';
import Dropdown from '../../components/dropdown/dropdown';
import CategoryForm from '../../components/NewCategory/newCategory';
import DeleteDialog from '../../components/DeleteDialog/DeleteDialog';

require('./password.styl');

export default class Password extends React.Component {
	constructor (props) {
		super(props);
		
		this.state = {
			// 默认显示网站密码列表
			type: props.type,
			pwList: [],
			modify: -1,
			category: [],
			showIndex: -1,
			searchKey: '',
			deleteItemId: -1,
			deleteItemName: '',
			// 是否显示下拉菜单, 默认值不影响
			showDropdown: true,
			viewType: 'thumbnail',
			showCreateDialog: false,
			showCreateCategoryDialog: false
		};
	};
	
	componentDidMount () {
		this.getPassword();
	};
	
	componentWillReceiveProps (props) {
		let regetData = props.searchKey !== this.state.searchKey;
		
		this.setState({
			type: props.type,
			searchKey: props.searchKey,
			showCreateDialog: props.showCreateDialog
		}, () => {
			regetData && this.getPassword();
		});
	};
	
	getPassword () {
		Rx.DOM.ajax({
			method: 'GET',
			url: `/secret/${this.state.type}/list?name=${this.state.searchKey}`,
			responseType: 'json'
		})
		.subscribe( (data) => {
			this.setState({
				pwList: data.response.secretList,
				category: data.response.category
			});
		});
	};
	
	showPassword (index, show) {
		this.setState({
			showIndex: show ? index : -1
		});
	};
	
	editState (index) {
		this.setState({
			modify: index
		}, () => {
			this.props.toggleCreateDialog();
		});
	};
	
	deleteItem (id, name) {
		this.props.deleteRecord(
			{
				id: id,
				type: this.state.type,
				name: name
			}, 
			(success) => {// onDelete
				if (success) {
					this.setState({
						pwList: this.state.pwList.filter((item, index) => {
							return item.id !== id;
						})
					});
				} else {
					//TODO: add dialog for delete status message
					console.log('删除失败...');
				}
			}
		);
	};
	
	generateItem (item, index) {
		if (this.state.viewType == 'list') {
			return <li className='pw-item' key={index}>
					<span className='col index'>{index + 1}. </span>
					<a className='col col-md-1p5' href={item.url} target='_blank'>{item.name}</a>
					<span className='col col-md-2'>{Util.formatDate(item.date, 'YYYY/MM/DD HH:mm:ss')}</span>
					<span className='col col-md-2'>{item.register}</span>
					<span className={'col col-md-1' + (this.state.showIndex == index ? '' : ' hidden')}
						onMouseEnter={this.showPassword.bind(this, index, true)}
						onMouseOut={this.showPassword.bind(this, index, false)}>{item.password}</span>
					<span className='col col-md-1p5'>{item.note}</span>
					<button className='modify btn btn-primary'
						onClick={this.editState.bind(this, index)}>
						{this.state.modify == index ? '保存' : '修改'}
					</button>
					<button className='delete btn btn-danger'
						onClick={this.deleteItem.bind(this, item.id, item.name)}>删除</button>
				</li>
		} else {
			return <li className='pw-item' key={index}>
					<a className='name' href={item.url} target='_blank'>{item.name}</a>
					<div className='info'>
						<span className='s-b'>{item.register}</span>
						<span className={'s-b' + (this.state.showIndex == index ? '' : ' hidden')}
							onMouseEnter={this.showPassword.bind(this, index, true)}
							onMouseOut={this.showPassword.bind(this, index, false)}>{item.password}</span>
						<span className='s-b'>{item.note}</span>
						<span className='s-b'>{Util.formatDate(item.date, 'YYYY/MM/DD HH:mm:ss')}</span>
					</div>
					<div className='opts'>
						<button className='modify btn btn-primary'
							onClick={this.editState.bind(this, index)}>
								{this.state.modify == index ? '保存' : '修改'}
						</button>
						<button className='delete btn btn-danger'
							onClick={this.deleteItem.bind(this, item.id, item.name)}>删除</button>
					</div>
				</li>
		}
	};
	
	onSearch (value) {
		Rx.DOM.ajax({
			method: 'GET',
			url: `/secret/${this.state.type}/list?name=${value}`,
			responseType: 'json'
		})
		.subscribe( (data) => {
			this.setState({
				pwList: data.response.secretList,
				category: data.response.category
			});
		});
	};
	
	toggleCreateDialog (type, data) {
		if (type === 'password') {
			this.setState({
				modify: -1
			}, () => {
				this.props.toggleCreateDialog();
			});
		} else {
			this.setState({
				showCreateCategoryDialog: !this.state.showCreateCategoryDialog,
				category: data
			});
		}
	};

	savePassword (data) {
		this.props.saveData(this.state.type, data, () => {
			this.getPassword();
		});
	};
	
	render () {
		return (
			<div id='password'>
				<ul id={this.state.viewType == 'list' ? 'list' : 'thumbnail'}>
				{
					(() => {
						if (this.state.pwList.length) {
							return this.state.pwList.map((item, index) => this.generateItem.call(this, item, index))
						} else {
							return <li className='no-record'>No Record.</li>
						}
					})()
					
				}
				</ul>
				<PasswordForm
					isModify={this.state.modify > -1}
					entity={(() => {
						if (this.state.modify > -1) {
							return this.state.pwList[this.state.modify];
						}
						
						return null;
					})()}
					saveSecret={this.savePassword.bind(this)}
					showCreateDialog={this.state.showCreateDialog}
					toggleCreateDialog={this.toggleCreateDialog.bind(this, 'password')} />
			</div>
		);
	};
}
