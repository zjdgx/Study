/**
 * Build Date: 2016/07/15 14:10.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description: new password form
 */
'use strict';

import $ from 'jquery';
import Rx from 'rx-dom';
import React from 'react';
import ReactDOM from 'react-dom';
import Util from '../../../utils';
import Dialog from '../../../components/Dialog';
import Dropdown from '../../../components/dropdown/dropdown';

export default class NewPassword extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			modify: false,
			newProps: {
				url: '',
				name: '',
				note: '',
				password: '',
				register: ''
			},
			showCreateDialog: props.showCreateDialog
		};
	};
	
	componentWillReceiveProps (props) {
		// 设置弹出框是否显示
		this.setState({
			modify: props.isModify,
			showCreateDialog: props.showCreateDialog,
			newProps: Object.assign(this.state.newProps, props.entity)
		});
	};
	
	componentWillUpdate (nextProps, nextState) {
		/*if (!Util.isObjectEqual(nextState.newProps, this.state.newProps)) {
			return false;
		} else {
			this.setState({
				newProps: nextState.newProps
			});
		}*/
	};
	
	onInputChange (e) {
		let newProps = {};
		
		newProps[e.target.name] = e.target.value;
		
		this.setState({
			newProps: Object.assign(this.state.newProps, newProps)
		});
	};

	onPasswordCreateDialog (type) {
		this.setState({
			showCreateDialog: type == 'save'
		}, () => {
			(type != 'save') && this.props.toggleCreateDialog();
			if ('cancel' !== type && this.checkNetParameters()) {
				this.props.saveSecret(
					Object.assign(
						this.state.modify ? {id: this.state.newProps.id} : {},
						{
							url: this.state.newProps.url,
							netName: this.state.newProps.name,
							note: this.state.newProps.note || '',
							password: this.state.newProps.password,
							register: this.state.newProps.register
						}
					)
					
				);
			} else {
				console.log('参数不能为空...');
				this.state.newProps.id && this.props.resetModifyState();
			}
		});
	};
	
	checkNetParameters () {
		return Util.checkUrl(this.state.newProps.url)
				&& this.state.newProps.name.length
				&& this.state.newProps.password.length;
	};
	
	render () {
		return (
			<Dialog
				type='dialog'
				title='New Password'
				sureText='保存'
				className={'create-dialog' + (this.state.showCreateDialog ? '' : ' hide')}
				onSaveAndClose={this.onPasswordCreateDialog.bind(this, 'saveClose')}
				onSure={this.onPasswordCreateDialog.bind(this, 'save')}
				onCancel={this.onPasswordCreateDialog.bind(this, 'cancel')}
			>
				<div className='item'>
					<label for='name'>网站名字:</label>
					<input type='text' name='name' ref='name' value={this.state.newProps.name} onChange={this.onInputChange.bind(this)}/>
				</div>
				<div className='item'>
					<label for='register'>注册方式:</label>
					<input type='text' name='register' ref='register' value={this.state.newProps.register} onChange={this.onInputChange.bind(this)}/>
				</div>
				<div className='item'>
					<label for='url'>网站地址:</label>
					<input type='text' name='url' ref='url' value={this.state.newProps.url} onChange={this.onInputChange.bind(this)}/>
				</div>
				<div className='item'>
					<label for='password'>注册密码:</label>
					<input type='text' name='password' ref='password' value={this.state.newProps.password} onChange={this.onInputChange.bind(this)}/>
				</div>
				<div className='item'>
					<label for='note'>备&emsp;&emsp;注:</label>
					<input type='text' name='note' ref='note' value={this.state.newProps.note} onChange={this.onInputChange.bind(this)}/>
				</div>
			</Dialog>
		);
	}
}
