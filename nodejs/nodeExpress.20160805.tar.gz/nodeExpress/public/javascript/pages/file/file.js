/**
 * Build Date: 2016/08/02 13:33.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description:
 *	file component
 */
 
'use strict';

import Rx from 'rx-dom';
import React from 'react';

import NewFile from './components/newFile';

require('./file.styl');

export default class File extends React.Component {
	constructor (props) {
		super(props);
		this.state = {
			type: props.type,
			fileList: [],
			modify: -1,
			showIndex: -1,
			searchKey: '',
			showCreateDialog: false
		}
	};
	
	componentWillMount () {
		this.getFileList();
	};
	
	componentWillReceiveProps (props) {
		let regetData = props.searchKey !== this.state.searchKey;
		
		this.setState({
			type: props.type,
			searchKey: props.searchKey,
			showCreateDialog: props.showCreateDialog
		}, () => {
			regetData && this.getfileList();
		});
	};
	
	getFileList () {
		Rx.DOM.ajax({
			type: 'GET',
			url: `/secret/${this.state.type}/list?name=${this.state.searchKey}`,
			responseType: 'json'
		})
		.subscribe(
			(data) => {
				this.setState({
					fileList: data.response.secretList
				});
			},
			(err) => {
				console.log(JSON.stringify(err));
			}
		);
	};
	
	editState (index) {
		this.setState({
			modify: index,
			showCreateDialog: index > -1
		});
	};
	
	saveFile (data) {
		this.props.saveData(this.state.type, data, () => {
			this.getFileList();
		});
	};
	
	deleteItem (id, name) {
		this.props.deleteRecord(
			{
				id: id,
				type: this.state.type,
				name: name
			}, 
			(success) => {// onDelete
				if (success) {
					this.setState({
						fileList: this.state.fileList.filter((item, index) => {
							return item.id !== id;
						})
					});
				} else {
					//TODO: add dialog for delete status message
					console.log('删除失败...');
				}
			}
		);
	};
	
	toggleCreateDialog () {
		this.setState({
			modify: -1
		}, () => {
			this.props.toggleCreateDialog();
		});
	};
	
	showPassword (index, show) {
		this.setState({
			showIndex: show ? index : -1
		});
	};
	
	render () {
		return (
			<div id='file'>
				<ul className='flex-container'>
				{
					this.state.fileList.map( (item, index) => {
						return <li className='flex-item' key={index}>
								<div className='info'>
									<span className='s-b name'>{item.name}</span>
									<span className='s-b date'>{item.date}</span>
									<span className='s-b address'>{item.address}</span>
									<span className={'s-b password' + (this.state.showIndex === index ? '' : ' hidden')}
										onMouseEnter={this.showPassword.bind(this, index, true)}
										onMouseOut={this.showPassword.bind(this, index, false)}>{item.password}</span>
								</div>
								<div className='flex-container opts'>
									<button className='flex-item modify btn btn-primary'
										onClick={this.editState.bind(this, index)}>
											{this.state.modify == index ? '保存' : '修改'}
									</button>
									<button className='flex-item delete btn btn-danger'
										onClick={this.deleteItem.bind(this, item.id, item.name)}>删除</button>
								</div>
							</li>;
					})
				}
				</ul>
				<NewFile
					isModify={this.state.modify > -1}
					entity={(() => {
						if (this.state.modify > -1) {
							return this.state.fileList[this.state.modify];
						}
						
						return null;
					})()}
					resetModifyState={this.editState.bind(this)}
					saveSecret={this.saveFile.bind(this)}
					showCreateDialog={this.state.showCreateDialog}
					toggleCreateDialog={this.toggleCreateDialog.bind(this)} />
			</div>
		);
	};
}