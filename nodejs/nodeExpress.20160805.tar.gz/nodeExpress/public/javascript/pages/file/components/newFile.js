/**
 * Build Date: 2016/08/01 14:06.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description:
 *	qq new form
 */
 
'use strict';

import Rx from 'rx-dom';
import React from 'react';

import Dialog from '../../../components/Dialog';

export default class NewQQ extends React.Component {
	
	constructor(props) {
		super(props);
		this.state = {
			modify: false,
			newProps: {
				qq: '',
				password: ''
			},
			showCreateDialog: props.showCreateDialog
		};
	};
	
	componentWillReceiveProps (props) {
		// 设置弹出框是否显示
		this.setState({
			modify: props.isModify,
			showCreateDialog: props.showCreateDialog,
			newProps: Object.assign(this.state.newProps, props.entity)
		});
	};
	
	onInputChange (e) {
		let newProps = {};
		
		newProps[e.target.name] = e.target.value;
		
		this.setState({
			newProps: Object.assign(this.state.newProps, newProps)
		});
	};
	
	onSaveQQ(type) {
		this.setState({
			showCreateDialog: type == 'save'
		}, () => {
			(type != 'save') && this.props.toggleCreateDialog();
			if ('cancel' !== type
					&& this.state.newProps.qq.length
					&& this.state.newProps.password.length) {
				this.props.saveSecret(JSON.stringify({
					qq: this.state.newProps.qq,
					password: this.state.newProps.password
				}));
			} else {
				console.log('参数不能为空...');
				this.state.newProps.id && this.props.resetModifyState();
			}
		});
	};
	
	render () {
		return (
			<Dialog
				type='dialog'
				title='New Password'
				sureText='保存'
				className={'password-add-dialog' + (this.state.showCreateDialog ? '' : ' hide')}
				onSure={this.onSaveQQ.bind(this, 'save')}
				onCancel={this.onSaveQQ.bind(this, 'cancel')}
			>
				<div className='item'>
					<label for='qq'>&emsp;&emsp;&emsp;&emsp;QQ:</label>
					<input type='text' name='qq' ref='qq' 
						value={this.state.newProps.qq}
						onChange={this.onInputChange.bind(this)}/>
				</div>
				<div className='item'>
					<label for='password'>密码:</label>
					<input type='text' name='password' ref='password'
						value={this.state.newProps.name}
						onChange={this.onInputChange.bind(this)}/>
				</div>
			</Dialog>
		);
	};
}