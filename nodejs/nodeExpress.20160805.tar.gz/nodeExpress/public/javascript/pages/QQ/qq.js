/**
 * Build Date: 2016/07/20 15:15.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description:
 *	qq component
 */
 
'use strict';

import Rx from 'rx-dom';
import React from 'react';

import NewQQ from './components/newQQ';

require('./qq.styl');

export default class QQ extends React.Component {
	constructor (props) {
		super(props);
		this.state = {
			type: props.type,
			QQList: [],
			modify: -1,
			showIndex: -1,
			searchKey: '',
			showCreateDialog: false
		}
	};
	
	componentWillMount () {
		this.getQQList();
	};
	
	componentWillReceiveProps (props) {
		let regetData = props.searchKey !== this.state.searchKey;
		
		this.setState({
			type: props.type,
			searchKey: props.searchKey,
			showCreateDialog: props.showCreateDialog
		}, () => {
			regetData && this.getQQList();
		});
	};
	
	getQQList () {
		Rx.DOM.ajax({
			type: 'GET',
			url: `/secret/${this.state.type}/list?name=${this.state.searchKey}`,
			responseType: 'json'
		})
		.subscribe(
			(data) => {
				this.setState({
					QQList: data.response.secretList
				});
			},
			(err) => {
				console.log(JSON.stringify(err));
			}
		);
	};
	
	editState (index) {
		this.setState({
			modify: index,
			showCreateDialog: index > -1
		});
	};
	
	saveQQ (data) {
		this.props.saveData(this.state.type, data, () => {
			this.getQQList();
		});
	};
	
	deleteItem (id, name) {
		this.props.deleteRecord(
			{
				id: id,
				type: this.state.type,
				name: name
			}, 
			(success) => {// onDelete
				if (success) {
					this.setState({
						QQList: this.state.QQList.filter((item, index) => {
							return item.id !== id;
						})
					});
				} else {
					//TODO: add dialog for delete status message
					console.log('删除失败...');
				}
			}
		);
	};
	
	toggleCreateDialog () {
		this.setState({
			modify: -1
		}, () => {
			this.props.toggleCreateDialog();
		});
	};
	
	showPassword (index, show) {
		this.setState({
			showIndex: show ? index : -1
		});
	};
	
	render () {
		return (
			<div id='qq'>
				<ul className='flex-container'>
				{
					this.state.QQList.map( (item, index) => {
						return <li className='flex-item' key={index}>
								<div className='info'>
									<span className='qq'>{item.qq}</span>
									<span className={'s-b password' + (this.state.showIndex === index ? '' : ' hidden')}
										onMouseEnter={this.showPassword.bind(this, index, true)}
										onMouseOut={this.showPassword.bind(this, index, false)}>{item.password}</span>
								</div>
								<div className='flex-container opts'>
									<button className='flex-item modify btn btn-primary'
										onClick={this.editState.bind(this, index)}>
											{this.state.modify == index ? '保存' : '修改'}
									</button>
									<button className='flex-item delete btn btn-danger'
										onClick={this.deleteItem.bind(this, item.id, item.qq)}>删除</button>
								</div>
							</li>;
					})
				}
				</ul>
				<NewQQ
					isModify={this.state.modify > -1}
					entity={(() => {
						if (this.state.modify > -1) {
							return this.state.QQList[this.state.modify];
						}
						
						return null;
					})()}
					resetModifyState={this.editState.bind(this)}
					saveSecret={this.saveQQ.bind(this)}
					showCreateDialog={this.state.showCreateDialog}
					toggleCreateDialog={this.toggleCreateDialog.bind(this)} />
			</div>
		);
	};
}