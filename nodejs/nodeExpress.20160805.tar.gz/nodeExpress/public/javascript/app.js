/**
 * Build Date: 2016/07/20 14:48.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description:
 *	use react router to develop a single page.
 */

'use strict';

import React from 'react';
import ReactDOM from 'react-dom';

import Secret from './secret';

ReactDOM.render(
	<Secret />
, document.getElementById('content'));
