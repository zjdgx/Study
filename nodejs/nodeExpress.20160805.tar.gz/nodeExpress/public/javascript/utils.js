/**
 * Build Date: 2016/07/04 11:41.
 * Copyright (c): ZJDGX
 * Autor: ZJDGX
 * Description: utils
 */
 
import moment from 'moment';
 
exports.formatDate = (dateStr, format) => {
	return moment(dateStr).format(format);
}

exports.checkUrl = (url) => {
	return /https?:\/\/(?:www\.|(?!www))[^\s\.]+\.[^\s]{2,}|www\.[^\s]+\.[^\s]{2,}/.test(url);
}

function isObjectEqual (obj1, obj2) {
	if (isPlainObject(obj1) && isPlainObject(obj2)) {
		let key1 = Object.keys(obj1),
				key2 = Object.keys(obj2);

		if (key1.length != key2.length) {
			return false;
		} else {
			for (let i = 0, len = key1.length; i < len; i++) {
				if (!obj2[key1[i]]) {
					return false;
				} else {
					return isObjectEqual(obj1[key1[i]], obj2[key1[i]]);
				}
			}
		}
	} else {
		return obj1 == obj2;
	}
}

function isPlainObject (obj) {
	try {
		if (obj.constructor
				&& !Object.prototype.hasOwnProperty.call(obj, 'constructor')
				&& !Object.prototype.hasOwnProperty.call(obj.constructor.prototype, 'isPrototypeOf')) {
			return false;
		}
	} catch (e) {
		// IE8,9 Will throw exceptions on certain host objects #9897
		return false;
	}

	let key;
	for (key in obj) {}

	return key === undefined || Object.prototype.hasOwnProperty.call(obj, key);
}

exports.isPlainObject = isPlainObject;
exports.isObjectEqual = isObjectEqual;