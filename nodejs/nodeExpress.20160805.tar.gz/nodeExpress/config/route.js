exports.route = [
	//============== password routes ==============//
	{
		type: 'get',
		url: '/',
		method: 'showPasswordPage',
		path: './lib/secret/PasswordController.js'
	},
	{
		type: 'get',
		url: '/secret/:type/list',
		method: 'getSecret',
		path: './lib/secret/PasswordController.js'
	},
	{
		type: 'post',
		url: '/secret/:type/add',
		method: 'addSecret',
		path: './lib/secret/PasswordController.js'
	},
	{
		type: 'put',
		url: '/secret/:type/:id',
		method: 'updateSecret',
		path: './lib/secret/PasswordController.js'
	},
	{
		type: 'delete',
		url: '/secret/:type/:id',
		method: 'deleteSecret',
		path: './lib/secret/PasswordController.js'
	},
	//============== category routes ==============//
	{
		type: 'get',
		url: '/category',
		method: 'getCategory',
		path: './lib/secret/Category.js'
	},
	{
		type: 'post',
		url: '/category/add',
		method: 'addCategory',
		path: './lib/secret/Category.js'
	}
];