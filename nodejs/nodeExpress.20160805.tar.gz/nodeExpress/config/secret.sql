/*
Navicat MySQL Data Transfer

Source Server         : zjdgx
Source Server Version : 50542
Source Host           : localhost:3306
Source Database       : secret

Target Server Type    : MYSQL
Target Server Version : 50542
File Encoding         : 65001

Date: 2016-08-02 15:26:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', '2016-07-18 19:00:26', 'net');
INSERT INTO `category` VALUES ('2', '2016-07-22 10:44:21', 'file');
INSERT INTO `category` VALUES ('3', '2016-07-22 11:07:27', 'qq');
INSERT INTO `category` VALUES ('4', '2016-07-28 10:33:54', 'id');
INSERT INTO `category` VALUES ('5', '2016-08-02 15:24:52', 'todo');

-- ----------------------------
-- Table structure for file
-- ----------------------------
DROP TABLE IF EXISTS `file`;
CREATE TABLE `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `date` datetime NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of file
-- ----------------------------
INSERT INTO `file` VALUES ('1', 'nodeExpress.20160801.jar', '2016-08-02 13:44:11', '网盘/projects', '02b6b6276861eccc79b1c60619185a4a');
INSERT INTO `file` VALUES ('3', 'photo-01.zip', '2016-07-05 14:02:00', '网盘/photo/photo-01.zip', '242f970640e267bd058ec99ffc820444');
INSERT INTO `file` VALUES ('4', '飞信', '2013-11-01 10:00:00', '13540273364', '322a42f5f69a561943a6c84b16b89569');
INSERT INTO `file` VALUES ('5', 'Evernote', '2014-12-15 10:00:00', '373687921@qq.com', '322a42f5f69a561943a6c84b16b89569');

-- ----------------------------
-- Table structure for id
-- ----------------------------
DROP TABLE IF EXISTS `id`;
CREATE TABLE `id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL DEFAULT '',
  `phone` int(11) DEFAULT NULL,
  `birthday` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `type` tinyint(2) DEFAULT NULL,
  `idcard` varchar(18) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of id
-- ----------------------------
INSERT INTO `id` VALUES ('1', '蒋兰', null, '(阴)1987/06/25', null, null, null);

-- ----------------------------
-- Table structure for net
-- ----------------------------
DROP TABLE IF EXISTS `net`;
CREATE TABLE `net` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `netName` varchar(45) NOT NULL,
  `url` varchar(100) NOT NULL,
  `register` varchar(45) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `note` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of net
-- ----------------------------
INSERT INTO `net` VALUES ('18', '2016-07-05 14:18:27', 'Android_eoe论坛', 'http://www.eoeandroid.com/', '373687921@qq.com', '322a42f5f69a561943a6c84b16b89569', '注册手机:18080109975');
INSERT INTO `net` VALUES ('20', '2016-07-05 15:32:46', '115', 'http://www.115.com/', '373687921@qq.com', '46ce2d6b3e8dcaedd84eacf07d7d819e', '');
INSERT INTO `net` VALUES ('21', '2016-07-05 15:33:08', 'Yobi', 'http://yobi.navercorp.com/', 'george', '38a6a13e74f80d4e67dcd2abc2249ba6', '');
INSERT INTO `net` VALUES ('22', '2016-07-05 15:33:24', 'CSDN', 'http://www.csdn.net/', 'georgejg', 'ac62487980f35bc3280045203abde698', '');
INSERT INTO `net` VALUES ('23', '2016-07-05 15:33:53', 'amazon', 'http://www.amazon.cn', '373687921@qq.com', '322a42f5f69a561943a6c84b16b89569', '');
INSERT INTO `net` VALUES ('24', '2016-07-05 15:34:39', 'github', 'https://github.com/', 'zjdgx20131030@163.com', '7fef231a1dad496ed2038babd0dd8db3', '');
INSERT INTO `net` VALUES ('25', '2016-07-05 15:35:04', '百度统计', 'http://tongji.baidu.com/web/7064939/overview/sole', 'zjdgx', '322a42f5f69a561943a6c84b16b89569', '');
INSERT INTO `net` VALUES ('26', '2016-07-05 15:36:30', 'Adobe', 'http://www.adobe.com/cn/', '373687921@qq.com', '322a42f5f69a561943a6c84b16b89569', 'birthday:1984-02-18');
INSERT INTO `net` VALUES ('28', '2016-07-05 15:37:27', '知乎', 'http://www.zhihu.com/', 'zjdgx20131030@163.com', '86e034975cb6808ff574534db9e27500', '');
INSERT INTO `net` VALUES ('29', '2016-07-05 15:37:52', '彩票', 'http://dyj.asgardgame.com/dyj/index.html', '13540273364', '322a42f5f69a561943a6c84b16b89569', '');
INSERT INTO `net` VALUES ('30', '2016-07-05 15:38:20', '网易邮箱', 'http://www.mail.163.com/', 'zjdgx20150325@163.com', '7fef231a1dad496ed2038babd0dd8db3', '');
INSERT INTO `net` VALUES ('31', '2016-07-05 15:38:46', 'github', 'https://github.com/', 'zjdgx20150325@163.com', '7fef231a1dad496ed2038babd0dd8db3', '');
INSERT INTO `net` VALUES ('32', '2016-07-05 15:39:16', '招聘-智联', 'http://www.zhaopin.com/', 'jianggang060615@163.com', '46ce2d6b3e8dcaedd84eacf07d7d819e', '');
INSERT INTO `net` VALUES ('33', '2016-07-05 15:39:35', '招聘-无忧', 'http://www.51job.com/', 'jianggang060615@163.com', '46ce2d6b3e8dcaedd84eacf07d7d819e', '');
INSERT INTO `net` VALUES ('34', '2016-07-05 15:39:59', '新浪微博', 'http://weibo.com/', '373687921@qq.com', '322a42f5f69a561943a6c84b16b89569', '');
INSERT INTO `net` VALUES ('35', '2016-07-05 15:42:57', '网易邮箱126', 'http://mail.126.com', 'jianggang0110@126.com', '43d03f69673c931f8af6552117d79644', '');
INSERT INTO `net` VALUES ('36', '2016-07-05 15:43:18', '国美', 'http://www.gome.com.cn/', '13540273364', '61c50cd6ff1fe63621ebde980a9077cd', '');
INSERT INTO `net` VALUES ('37', '2016-07-05 15:43:45', '去哪儿', 'http://www.qunar.com/', '373687921@qq.com', '322a42f5f69a561943a6c84b16b89569', '');
INSERT INTO `net` VALUES ('38', '2016-07-05 15:44:01', '携程', 'http://www.ctrip.com/', '373687921@qq.com', '322a42f5f69a561943a6c84b16b89569', '');
INSERT INTO `net` VALUES ('39', '2016-07-05 15:44:41', 'jsfiddle', 'http://jsfiddle.net/', 'zjdgx20131030@163.com', '242f970640e267bd058ec99ffc820444', '注册时间:2015-12-04');
INSERT INTO `net` VALUES ('40', '2016-07-05 15:45:53', '360云盘', 'http://yunpan.360.cn/', '373687921@qq.com', 'ac62487980f35bc3280045203abde698', '');
INSERT INTO `net` VALUES ('41', '2016-07-05 15:46:29', 'dropbox', 'https://www.dropbox.com/', '373687921@qq.com', '322a42f5f69a561943a6c84b16b89569', '');
INSERT INTO `net` VALUES ('42', '2016-07-05 15:47:31', 'twitter', 'https://twitter.com/', '373687921@qq.com', '7fef231a1dad496ed2038babd0dd8db3', '注册时间:2016-06-01');
INSERT INTO `net` VALUES ('43', '2016-07-05 15:48:04', 'Microsoft', 'https://onedrive.live.com/', '373687921@qq.com', '322a42f5f69a561943a6c84b16b89569', '注册时间:2016-06-01');
INSERT INTO `net` VALUES ('44', '2016-07-05 15:48:29', 'strikingly', 'http://www.strikingly.com/', '373687921@qq.com', '263a54a2a805bab6b3bb88eac2e2d2c3', '注册时间:2016-06-02');
INSERT INTO `net` VALUES ('45', '2016-07-05 15:48:59', '万网', 'http://www.net.cn/', '35670394', '490c85b42339b29da67972b40a3ba5df', '');

-- ----------------------------
-- Table structure for qq
-- ----------------------------
DROP TABLE IF EXISTS `qq`;
CREATE TABLE `qq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qq` int(11) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of qq
-- ----------------------------
INSERT INTO `qq` VALUES ('1', '373687921', '812b5071b6476e49da03853c8e1356df');
INSERT INTO `qq` VALUES ('2', '303663087', '322a42f5f69a561943a6c84b16b89569');
INSERT INTO `qq` VALUES ('11', '970174822', '8caa53f42bbb68f1a03854a0a02746f79d2fdb68bdf49e9201f5b6d67478ca648b8c2aa9b68f1c43');
INSERT INTO `qq` VALUES ('12', '963649296', '8caa53f42bbb68f1a03854a0a02746f79d2fdb68bdf49e9201f5b6d67478ca648b8c2aa9b68f1c43');
INSERT INTO `qq` VALUES ('14', '1183913070', '8caa53f42bbb68f1a03854a0a02746f79d2fdb68bdf49e9201f5b6d67478ca648b8c2aa9b68f1c43');
INSERT INTO `qq` VALUES ('15', '1025353200', '8caa53f42bbb68f1a03854a0a02746f79d2fdb68bdf49e9201f5b6d67478ca648b8c2aa9b68f1c43');
INSERT INTO `qq` VALUES ('16', '1019253034', 'b8d5c5af60161b602a9ab0679430312914462b2f80cc3ee3b8b2169771eb7700cf6e2efa2673768a');
INSERT INTO `qq` VALUES ('17', '794622709', '2cf93c6fa80a85f5ae92b221dbd9c475bf193881ca43d0a191e70947d21702e6eb19df7c2d6aabdc');

-- ----------------------------
-- Table structure for todo
-- ----------------------------
DROP TABLE IF EXISTS `todo`;
CREATE TABLE `todo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task` varchar(30) NOT NULL,
  `startDate` datetime NOT NULL,
  `endDate` datetime DEFAULT NULL,
  `type` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of todo
-- ----------------------------
