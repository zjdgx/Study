module.exports = {
	host: '127.0.0.1',
	user: 'root',
	password: 'root',
	database: 'secret'
};