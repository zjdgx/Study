var path = require('path'),
		webpack = require('webpack'),
		CopyWebpackPlugin = require('copy-webpack-plugin'),
		ExtractTextPlugin = require('extract-text-webpack-plugin');

module.exports = {
	entry: {
		react: ['react'],
		jquery: ['jquery'],
		secret: './public/javascript/app.js'
	},
	output: {
		path: './dist',
		filename: 'js/[name].js'
	},
	devtool: 'inline-source-map',
	module: {
		loaders: [
			{
				test: /\.(js|jsx)$/,
				loader: 'babel-loader',
				exclude: /node_modules/,
				query: {
					cacheDirectory: true,
					plugins: ['transform-decorators-legacy', 'transform-runtime'],
					presets: ['es2015', 'stage-0', 'react']
				}
			},
			{
				test: /\.(css|styl)$/,
				loader: ExtractTextPlugin.extract('style', '!css!stylus')
			},
			{
				test: /\.(eot|svg|ttf|woff(2)?)(\?v=\d+\.\d+\.\d+)?/,
				loader: 'url'
			}
		]
	},
	plugins: [
		new webpack.optimize.CommonsChunkPlugin({
				// 提取公共模块
				name: ['react'],
				minChunks: Infinity // 提取所有entry共同依赖的模块
		}),
		new CopyWebpackPlugin([
			{from: './public/images', to: 'image'}
		]),
		new ExtractTextPlugin('css/[name].css')
	]
}
