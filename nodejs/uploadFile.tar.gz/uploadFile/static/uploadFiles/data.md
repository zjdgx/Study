data for index.tpl
=====
```
array (
  'categories' => 
  array (
    0 => 
    array (
      'id' => 69,
      'title' => '美容',
      'level' => 1,
      'orderSeq' => 5,
      'autoUpdateTime' => '2016-09-13 00:57:59',
      'createDate' => '2016-09-05 23:33:14',
    ),
    1 => 
    array (
      'id' => 68,
      'title' => '母婴',
      'level' => 1,
      'orderSeq' => 4,
      'autoUpdateTime' => '2016-09-13 00:57:42',
      'createDate' => '2016-09-05 23:33:14',
    ),
    2 => 
    array (
      'id' => 67,
      'title' => '彩妆',
      'level' => 1,
      'orderSeq' => 3,
      'autoUpdateTime' => '2016-09-13 00:57:42',
      'createDate' => '2016-09-05 23:33:14',
    ),
    3 => 
    array (
      'id' => 66,
      'title' => '女装',
      'level' => 1,
      'orderSeq' => 2,
      'autoUpdateTime' => '2016-09-13 00:57:59',
      'createDate' => '2016-09-05 23:33:14',
    ),
    4 => 
    array (
      'id' => 54,
      'title' => '海淘',
      'level' => 1,
      'orderSeq' => 1,
      'autoUpdateTime' => '2016-09-13 00:57:59',
      'createDate' => '2016-09-05 23:31:41',
    ),
    5 => 
    array (
      'id' => 53,
      'title' => '时尚11',
      'level' => 1,
      'autoUpdateTime' => '2016-09-13 23:58:07',
      'createDate' => '2016-09-05 23:31:31',
    ),
  ),
)

array (
  'guides' => 
  array (
    'items' => 
    array (
      0 => 
      array (
        'id' => 60,
        'title' => '《值客说》第43期：英镑跌到8块8， 拔草英淘好时机！英淘攻略&好物都在这儿了',
        'description' => '<p>6月24日，我们还在看独立日的时候英国脱欧啦！感觉好莱坞早已看透一切呢~小小MOON只想带个小喇叭 告诉大家：大不列颠，大不列颠，及北爱尔兰联合王国脱欧了!&nbsp;原价都是9.8,9.7,9.6的英镑，现在通通8.8，通通8.8，再不英淘就是亏！本期 DEALMOON说汇集了英淘方方面面的知识，从购物攻略到好物推荐，长草英淘的话现在可是下手好时机~</p>
<p>海淘淘得好来当生活家！还不知道什么是&ldquo;生活家&rdquo;的值友看这里，俗话说世事洞明皆学问，处处都有老司机。只有愿意用心感受生活、发现生活，每个人都可能是独当一面的&ldquo;生活家&rdquo;。欢迎大家积极加入什么值得买生活家阵营，传授你的独家经验。</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473329528961"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<p class="dm_split">&nbsp;</p>',
        'image' => 
        array (
          'url' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/692/fea/73f/76c/0c1/32f/a43/9c4/2c4/db7/10.jpg_600_0_15_d154.jpg',
        ),
        'images' => 
        array (
        ),
        'category' => 
        array (
          'id' => 53,
          'nameCh' => '时尚11',
        ),
        'author' => 
        array (
          'id' => '1',
          'name' => '牟佳斌',
          'avatar' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/b9d/dfd/a54/49d/d64/892/f2d/7cd/5e8/198/28.jpg_200_200_2_a810.jpg',
        ),
        'publishedTime' => 1473331813,
        'isFavorite' => false,
        'isLike' => false,
        'commentNum' => 0,
        'url' => '',
        'comments' => 
        array (
        ),
        'udid' => '1',
        'isRecommend' => true,
        'isEditable' => false,
        'canShare' => false,
        'sp' => 
        array (
        ),
        'shareUserCount' => 0,
      ),
      1 => 
      array (
        'id' => 54,
        'title' => '2016新版：BELLE MAISON 千趣会 日本女性时尚用品商城 手把手购物攻略',
        'description' => '<p>Belle Maison成立于1955年，是日本千趣会旗下的电商网站，是日本知名度非常高一个购物网站，专门销售女性时尚用品，<strong>也是日本女性最常用的购物网站之一</strong>。在日本的女性中可以说是无人不晓。从女孩时代开始穿着千趣会的衣服，到女孩成为母亲，又有了自己的女儿，然后向女儿再推荐千趣会邮购服饰。千趣会就是这样一个被大众所喜爱的品牌。千趣会攻略之前于我站发布过，随着该网站在国内名气的增大，小编在上一版攻略的基础上新增了选品，形成了2016新版攻略。</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/7a6/11a/8c4/f53/9a4/f2a/58e/fc2/aa1/6ee/8c.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>浏览日本千趣会官网就会知道这是个大型网站，网站上的商品一应俱全，从妈咪宝贝用品、家居日杂、化 妆品保健品到食物甜品、男女服饰鞋包等等，通通找得到，超好逛也超好买。不过还是以服饰为主。特别宽松也是为了穿着舒服吧。颜色也复古不是特别鲜亮，以前 买过无印良品的，日系感觉都差不多，不过千趣会价格更便宜，喜欢日系风格的姑娘们可以关注此网站。Belle Maison的迪士尼系列商品、女士内衣、哺乳衣、女装、母婴用品都是网站内的人气产品。</p>
<p>千趣会已经进驻中国，在天猫开有旗舰店，但是品类较少，只经营女装和母婴用品，人气款也常常款式和号码不全，所以要买到好东西还是要深入内部啊。今天什么值得买（SMZDM.COM）带着大家走进日本千趣会，我们一起来看看怎么买，都买什么。</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/77f/496/8fa/f78/e85/c9c/1df/6d0/615/055/6b.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>&nbsp;</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<h1 style="color: #000000; font-size: 24px; line-height: 24px; padding-left: 10px; margin-top: 20px; margin-bottom: 20px; border-left: 3px solid #ff4200;"><span style="color: #d42f2f;"><strong>购买攻略</strong></span></h1>
</blockquote>
<p>千趣会目前还不能直邮，需要转运。满5000日元日本境内包邮，不满收350日元的邮费。2016年8月31日22:59（北京时间）之前注册的新用户购物日本境内免邮，另外赠1000日元的优惠券，购物满5000日元（不含税），即5400日元（税入）可使用，优惠券有效期到2016年9月13日。</p>
<p>6.选择送达时间，如果你没特别指定，括号里写着&ldquo;无料&rdquo;，也就是免费的，选一个就行。然后确认订单，他大~~一次愉快的购物就结束了，坐等收包裹就好啦。</p>
<p>以上就是日本千趣会的购买流程，这里再给大家介绍几款网站人气产品，以后什么值得买（SMZDM.COM）也会持续关注这个网站，第一时间为各位网友推荐好的单品。</p>
<p>商品推荐<br />夏季棉麻女士上衣 价格：3229日元（约人民币211元）</p>
<p><iframe id="dm_discount_541330" class="dm_insert_block dm_discount" src="index.php?r=shopping-guide/deal-preview&amp;id=541330&amp;ck=e3554a0932e9bd9eaeb203149e41d360" width="600" height="110" frameborder="none" scrolling="no" data-type="deal_discount" data-id="541330"></iframe></p>
<p class="dm_split">&nbsp;<iframe id="dm_discount_542570" class="dm_insert_block dm_discount" src="index.php?r=shopping-guide/deal-preview&amp;id=542570&amp;ck=f7b3d2bd9d3442c38a3025f61fef31d1" width="600" height="110" frameborder="none" scrolling="no" data-type="deal_discount" data-id="542570"></iframe></p>
<p class="dm_split">&nbsp;</p>
<p>Ex:beaute是在日本销售了十几年的老牌子了，深受挑剔的日本女性欢迎。女优肌，顾名思义这 款粉底液本来是给女演员使用的，随着科技发展，高清摄像机让女演员的厚重妆容一览无余。于是就出现了这款既轻薄又有一定遮盖力的底妆产品。此款粉底液对毛 孔、色素沉着等凹凸不平之处能自然遮盖，长效控油持妆。&nbsp;</p>
<p>草花木果 卸妆油 308ml 价格：2808日元（约人民币183元）</p>
<p>&nbsp;</p>',
        'image' => 
        array (
          'url' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/04a/9c6/400/e99/908/b72/ae8/419/3c5/537/5f.jpg_600_0_15_4e66.jpg',
        ),
        'images' => 
        array (
          0 => 
          array (
            'url' => 'http://fsvr.dealmoon.com/dealmoon/7a6/11a/8c4/f53/9a4/f2a/58e/fc2/aa1/6ee/8c.jpg',
          ),
          1 => 
          array (
            'url' => 'http://fsvr.dealmoon.com/dealmoon/77f/496/8fa/f78/e85/c9c/1df/6d0/615/055/6b.jpg',
          ),
        ),
        'category' => 
        array (
          'id' => 53,
          'nameCh' => '时尚11',
        ),
        'author' => 
        array (
          'id' => '1',
          'name' => '牟佳斌',
          'avatar' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/b9d/dfd/a54/49d/d64/892/f2d/7cd/5e8/198/28.jpg_200_200_2_a810.jpg',
        ),
        'publishedTime' => 1473331593,
        'isFavorite' => false,
        'isLike' => false,
        'commentNum' => 0,
        'url' => '',
        'comments' => 
        array (
        ),
        'udid' => '1',
        'isRecommend' => true,
        'isEditable' => false,
        'canShare' => false,
        'sp' => 
        array (
        ),
        'shareUserCount' => 0,
      ),
      2 => 
      array (
        'id' => 53,
        'title' => '海淘攻略:Rakuten Global Market 乐天国际 手把手购物教程 2016最新版',
        'description' => '<p>乐天国际是日淘网友的主要淘货网站之一，之前站内为值友们推出过多篇乐天国际优质店铺的介绍文章，乐天市场也曾为我站提供过官方攻略，本次推出的2016年最新版购物教程，什么值得买（SMZDM.COM）对之前发布乐天国际攻略进行了更新汇总，同时增添乐天国际最新的购物流程及优质店铺，并推荐一些能让值友们的生活质量蹭蹭蹭提高的实用好物，希望能给需要的值友们带来帮助。</p>
<p>关于乐天国际<br />乐天市场（Rakuten Ichiba）连续多年在日本内销量第一，所售商品与实体店质量一致。优点是接受国际信用卡和国际派送，缺点是全日文界面，不能切换英文，不懂日语的人，要用到翻译器了。乐天国际市场（rakuten global），日本乐天的国际版，优点就是中文界面，有不少店铺现在支持银联，支付宝支付，不少商家可直邮中国，EMS从日本国内到中国一般2-3天。账号通用，在rakuten global注册一个账号可以上rakuten</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/f9e/9f7/1ab/42f/8d6/2ae/2ec/806/d56/33a/c5.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>&nbsp; &nbsp;</p>
<p><strong>关于支付宝</strong><br />支付宝和海外商家合作，使海淘变得更加容易方便，及时是海淘小白也毫无压力。支付宝和乐天国际市场也有合作了，每周三，在特定的店铺使用支付宝支付，即可享受5%折扣优惠，同时乐天国际市场有快速使用支付宝教程供大家参考。</p>
<p><strong>注册流程</strong><br />打开Rakuten乐天国际市场的首页，点击&ldquo;注册&rdquo;，加入会员。如果不注册的话，也可以成功下单，但无法获得积分奖励。</p>
<p>1.乐天国际的注册流程已经汉化，注册十分简便。但由于中文字符易在日本系统中显示为乱码，国内地址很不标准也普遍没有标准英文翻译，请全部用拼音填写（姓名、地址）；而且EMS到了中国境内，邮递员很可能不懂英文；因此可以直接用拼音填写地址。</p>
<p>2.如果出现如下图片，就是注册成功了。接下来开始Rakuten乐天国际市场的购物之旅吧~第三步的注册会员超级简单，只需要点击最下面的&ldquo;继续使用服务&rdquo;按键即可完成。</p>
<p><br /><strong>下单流程</strong></p>
<p>乐天国际配送目前有七千余家店铺在运营，每家店铺分别接单，发货，和付款，店铺之间不能合并发货。所有中文内容都是直接从店铺的乐天市场日文网页中直接翻译过来的，部分地方会翻译得不好。网站操作流程的汉化都做得没问题，商品详情介绍的汉化就做得不够详尽，搜索商品时，时而会出现和商品信息不匹配的信息。值友们可以从乐天市场日文网页搜索商品，再更改语言设置，从而降低搜索商品的难度，此方法在这里不过过多介绍，具体操作步骤戳这里。</p>
<p>因为是全中文页面，和国内网购类似，海淘新手也无压力。</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473321541175"><a href="http://www.dealmoon.com/post/103268?ck=undefined" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split"><a id="a_1473660870553" href="http://www.amazon.com?tag=dealmoon-20">点击购买&gt;&gt;&gt;&nbsp;</a></p>
<p>2、商家发的确认邮件</p>
<p>由于目的地国家和商品包装要求的差异，无法在下单之前给出运费数额。当店铺计算好邮件的运费之后，会以邮件形式通知各项费用，确认邮件里会有所购买的商品、价格、运费、地址、支付方式等等，需要修改可以直接邮件回复，没有问题也要回复。当确认完这封邮件中的信息之后，店铺才会扣款和发货。需注意：这封邮件是必须回复的，否则店家不会发货。可以用英文回复。</p>
<p><br />谈经验：我们的网友往往难以分辨哪封是需要回复的店铺邮件。需要回复的店铺邮件有以下特点：1.邮件来自店铺的邮箱，与店铺介绍网页里给出的一致；2.邮件标题或正文中有需要回复的提醒，Please confirm或者ご確認ください的字样；3. 邮件中有运费数额，这在系统邮件中是没有的。运费的英文是shipping expenses, 日语中叫做送料。</p>
<p>3、发货邮件</p>
<p>商家会发物流信息到注册邮箱，如果是直邮商品，店铺发货之后会邮件给您EMS运单号码和EMS官网链接，点链接进去复制粘贴追踪，可以查看包裹物流信息。如果是转运商品，接下来就多多关注转运公司的情况，用转运发回国内就大功告成了，转运攻略可参考我站2016最新版日亚攻略转运部分介绍。</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<p>商家会发物流信息到注册邮箱，如果是直邮商品，店铺发货之后会邮件给您EMS运单号码和EMS官网链接，点链接进去复制粘贴追踪，可以查看包裹物流信息。如果是转运商品，接下来就多多关注转运公司的情况，用转运发回国内就大功告成了，转运攻略可参考我站2016最新版日亚攻略转运部分介绍。</p>
<p>如何选择优质商家<br />很多人一提到乐天国际就会说，可能会认为店铺众多，疑虑是否存在假货现象，购物没有保证。实际上并不然，日本在打击假货上是非常严厉的，且日本法律和乐天有关规定，只有持有日本工商执照的注册企业才能申请在乐天市场开通网店，所售商品必须和其实体店质量一致，因此大店铺还是比较放心购买的。小编接下来就给各位介绍一些乐天国际上的大卖家以及热门商品。</p>
</blockquote>
<p><iframe id="dm_discount_541330" class="dm_insert_block dm_discount" src="index.php?r=shopping-guide/deal-preview&amp;id=541330&amp;ck=undefined" width="600" height="110" frameborder="none" scrolling="no" data-type="deal_discount" data-id="541330"></iframe></p>
<p class="dm_split">&nbsp;<iframe id="dm_discount_542570" class="dm_insert_block dm_discount" src="index.php?r=shopping-guide/deal-preview&amp;id=542570&amp;ck=undefined" width="600" height="110" frameborder="none" scrolling="no" data-type="deal_discount" data-id="542570"></iframe></p>
<p class="dm_split">&nbsp;</p>',
        'image' => 
        array (
          'url' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/593/2c9/c79/914/8ae/394/b60/37f/256/a8a/3b.jpg_600_0_15_f2ae.jpg',
        ),
        'images' => 
        array (
          0 => 
          array (
            'url' => 'http://fsvr.dealmoon.com/dealmoon/f9e/9f7/1ab/42f/8d6/2ae/2ec/806/d56/33a/c5.jpg',
          ),
        ),
        'author' => 
        array (
          'id' => '1',
          'name' => '牟佳斌',
          'avatar' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/b9d/dfd/a54/49d/d64/892/f2d/7cd/5e8/198/28.jpg_200_200_2_a810.jpg',
        ),
        'publishedTime' => 1473331579,
        'isFavorite' => false,
        'isLike' => false,
        'favoriteNum' => 1000,
        'commentNum' => 0,
        'url' => '',
        'comments' => 
        array (
        ),
        'udid' => '1',
        'isRecommend' => true,
        'isEditable' => false,
        'canShare' => false,
        'sp' => 
        array (
        ),
        'shareUserCount' => 0,
      ),
      3 => 
      array (
        'id' => 55,
        'title' => '英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记',
        'description' => '<p>英国脱欧之后，本宝宝坐等汇率下跌，心情澎拜，赶脚不买点什么就对不起卡梅伦了</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/edf/82e/4c3/534/a09/4fa/ca0/7a3/f11/871/ce.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn" style="display: none;">注释</button></div>
</div>
<div class="dm_comment mceEditable">这是英国首相&nbsp;</div>
</div>
</div>
<p>&nbsp;正好我家小子马上转口粮，1+转2+，原来一直在德国买（说的好像去过德国一样英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记 ），爱他美咩，地球人都知道，之前吃喜宝的，但是后来基本买不到了，国人确实厉害英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记 转战英国必须买牛栏啊，好歹在作为母婴之友的资深奶爸还是做了功课的。于是直奔牛栏大英帝国官网</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/842/3e5/5f2/c10/a73/347/ac3/c10/1bc/846/4f.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>到红框框里画的没，都可以买，相当于是牛栏英国官方指定购买地址，内心是比较放心的。于是乎开始度娘这几个站，TESCO和BOOTS可能值友们相对熟悉一些（连我都知道英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记 ），点卡差不多都是8英镑一盒，算上8.9的汇率基本上70来块钱吧，大英帝国的人民真幸福啊英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记 ，当我在比较的时候发现OCADO有个重大优惠：新客满80磅立减20磅！！长期混张大妈的都懂！那就是从它下手吧！</p>
<p>做完准备工作那就开始买买买吧，购物流程很简单，不过为了大家更直观，还是简单说下，会点鸟语的或者海淘小能手可以略过英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记。</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473326778912"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103267" data-dom-id="usg_1032671473326780204"><a href="http://www.dealmoon.com/post/103267?ck=23785752d9befebaafc237b27e3d671d" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/0a6/26b/d2a/997/9c2/a28/88d/02e/5ba/00c/ef.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/683/894/529/11d/6f0/134/bbc/86c/7b5/74c/de.jpg_200_200_2_ada2.jpg" /><span class="user-name">shibasamon</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">我们家的萌宠?</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473326781331"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473326782843"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<p>4、点击右上角cheakout去结算，基本跟亚马逊什么的类似，相对还是比较好操作的,依次填写 送货地址、日期（可以精确到时间段，建议上班时间送，毕竟大家走的都是转运）、付款信息（支持国卡，不支持银联），最后确认无误就下单，只要是工作日第二 天就能到转运仓库了。注意的是要收2英镑的税、打包盒运费，总共扣款是62英镑。</p>
<p><br />&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;我&mdash;&mdash;&mdash;&mdash;是&mdash;&mdash;&mdash;&mdash;邪&mdash;&mdash;&mdash;&mdash;恶&mdash;&mdash;&mdash;的&mdash;&mdash;&mdash;&mdash;分&mdash;&mdash;&mdash;隔&mdash;&mdash;&mdash;&mdash;线&mdash;&mdash;&mdash;</p>
<p>下面就到转运了，具体流程自行搜索吧。</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<h2 style="color: #000000; font-size: 18px; border-left: none; padding-left: 0px; margin-bottom: 10px; margin-top: 10px;">中间有个小插曲，货送到仓库两天没入库，就咨询了下，结果告知没有外包装，也就说没有外面的大盒子 &nbsp; &nbsp;好吧，转运提交的时候价格固，20块，嗯还比较便宜，加上某转运做活动，全场6.28折（大家都懂的），10盒运费加上加固一共花了255.34，1个礼拜到手，还是挺不错了。</h2>
</blockquote>
<p>中间被税了，这是预料之中的，没被退运，已经很满足啦 &nbsp; &nbsp;</p>',
        'image' => 
        array (
          'url' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/593/2c9/c79/914/8ae/394/b60/37f/256/a8a/3b.jpg_600_0_15_f2ae.jpg',
        ),
        'images' => 
        array (
          0 => 
          array (
            'url' => 'http://fsvr.dealmoon.com/dealmoon/edf/82e/4c3/534/a09/4fa/ca0/7a3/f11/871/ce.jpg',
          ),
          1 => 
          array (
            'url' => 'http://fsvr.dealmoon.com/dealmoon/842/3e5/5f2/c10/a73/347/ac3/c10/1bc/846/4f.jpg',
          ),
        ),
        'author' => 
        array (
          'id' => '1',
          'name' => '牟佳斌',
          'avatar' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/b9d/dfd/a54/49d/d64/892/f2d/7cd/5e8/198/28.jpg_200_200_2_a810.jpg',
        ),
        'publishedTime' => 1473331574,
        'isFavorite' => false,
        'isLike' => false,
        'likeNum' => 500,
        'commentNum' => 0,
        'url' => '',
        'comments' => 
        array (
        ),
        'udid' => '1',
        'isRecommend' => true,
        'isEditable' => false,
        'canShare' => false,
        'sp' => 
        array (
        ),
        'shareUserCount' => 0,
      ),
      4 => 
      array (
        'id' => 57,
        'title' => '黑五必看：美国亚马逊 直邮服务 手把手教程 2016最新版',
        'description' => '<p>美国亚马逊扩大直邮业务已经快两年了，这期间相信已经有不少值友通过直邮购买过美亚商品，在什么值得买（SMZDM.COM）日常的海淘推荐中也能看到很多值友分享美亚直邮的经验及反馈，目前美亚上面可直邮商品已经覆盖了服饰鞋包、母婴保健、美妆个护、数码3C、日百等大部分内容，可以说是非常适合海淘新手第一站，老手重复光顾的海淘热门商城。</p>
<p>今年黑五临近，为了给更多的值友指引，也为了对去年的攻略进行补充修正，什么值得买（SMZDM.COM）推出直邮服务 手把手教程2016版，包含如何寻找可直邮商品、购买、支付、查询订单、咨询客服以及Prime会员服务、Gift Cards购买等相关内容，将向大家展示如何完成一次完整的直邮购物过程。</p>
<div class="dm_insert_video dm_insert_block" contenteditable="false">
<div style="position: relative;"><embed type="application/x-shockwave-flash" class="edui-faked-video" play="false" loop="false" menu="false" allowscriptaccess="true" src="http://player.youku.com/player.php/sid/XMTcxNjQyMzQ5Ng==/v.swf" width="100%" height="290px" allowfullscreen="true" pluginspage="http://www.macromedia.com/go/getflashplayer" autostart="false" wmode="transparent" data-mce-fragment="1"></embed>
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
<p>&nbsp;</p>
<p>美国亚马逊 Amazon.com 最新优惠 丨 注册Prime会员 丨 购买Gift Cards 丨 黑五专区<br />美国亚马逊&nbsp;直邮服务常见问题解答<br />如果有过美亚购物经验的值友可以跳过第一部分注册流程，从购买可直邮商品开始看。</p>
<p>如何在美国亚马逊注册新账户<br />在美亚海淘首先需要准备一张支持美元的双币、多币信用卡或者银联信用卡，可以参照本站原创频道中的海淘信用卡选择经验。</p>
<p>1.打开美亚首页，在页面顶部可以看到黑色的导航条，点击右侧&ldquo;Your Account&rdquo;你的账户下面的&ldquo;Start here&rdquo;即可进入新账户注册页面。&nbsp;</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/296/863/079/fd3/a4b/6ad/e3e/6ff/229/ace/67.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473327867654"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103267" data-dom-id="usg_1032671473327868613"><a href="http://www.dealmoon.com/post/103267?ck=23785752d9befebaafc237b27e3d671d" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/0a6/26b/d2a/997/9c2/a28/88d/02e/5ba/00c/ef.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/683/894/529/11d/6f0/134/bbc/86c/7b5/74c/de.jpg_200_200_2_ada2.jpg" /><span class="user-name">shibasamon</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">我们家的萌宠?</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block dm_external_goods" contenteditable="false" data-type="external_product" data-pro_img_url="http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/082/aad/b33/09f/e58/568/90f/b37/c66/28b/5e.jpg_600_0_15_c488.jpg" data-pro_business="淘宝商家" data-pro_title="海淘大集合" data-pro_price="222" data-pro_links="http://ym.zdmimg.com/201511/16/5649d2ec6a96f8609.png_e600.jpg" data-id="28"><img class="pro_img" src="http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/082/aad/b33/09f/e58/568/90f/b37/c66/28b/5e.jpg_600_0_15_c488.jpg" />
<div class="pro_content">
<p class="business">淘宝商家</p>
<p class="content">海淘大集合</p>
<p class="price">222</p>
</div>
<a class="pro_buy" contenteditable="false" href="http://ym.zdmimg.com/201511/16/5649d2ec6a96f8609.png_e600.jpg" target="_blank">购买</a></div>
<p class="dm_split">&nbsp;</p>
<p class="dm_split">2. &nbsp; 填写注册信息。在新账户注册页面可以看到十分简洁的信息栏，按照下图中的注释填写信息即可，需注意，姓名需按照中文语序填写拼音即可，比如张大妈，就填写&ldquo;ZHANG DA MA&rdquo;，而不要写成&ldquo;DA MA ZHANG&rdquo;，填写完成后点击下方的&ldquo;Create your Amazon account&rdquo;即可创建新账户。</p>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/ab7/c5a/d54/dd5/748/f42/2cc/6fe/246/4de/ae.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p class="dm_split">&nbsp;</p>
<p><strong>完善个人信息</strong></p>
<p><br />不管是使用直邮服务还是通过转运购买，都建议在注册完新账户之后立刻完善自己的个人信息，包括收货地址、支付信息等，美亚会依据这些信息而将商品页面部分信息作出调整，方便选购，比如如果默认地址设置为中国，商品页面会自动显示这个商品是否能够直邮中国。</p>
<p>设置收货地址。点击导航条右侧的&ldquo;Your Account&rdquo;你的账户，进入账户信息页面，如下图所示，这个页面中可以看到Orders&nbsp;历史订单、Amazon Wallet&nbsp;支付信息、Settings&nbsp;账户设置等内容。</p>',
        'image' => 
        array (
          'url' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/d8f/a74/b40/7c9/d63/d9a/b20/11d/366/1e9/0b.jpg_600_0_15_98ee.jpg',
        ),
        'images' => 
        array (
          0 => 
          array (
            'url' => 'http://fsvr.dealmoon.com/dealmoon/296/863/079/fd3/a4b/6ad/e3e/6ff/229/ace/67.jpg',
          ),
          1 => 
          array (
            'url' => 'http://fsvr.dealmoon.com/dealmoon/ab7/c5a/d54/dd5/748/f42/2cc/6fe/246/4de/ae.jpg',
          ),
        ),
        'category' => 
        array (
          'id' => 54,
          'nameCh' => '海淘',
        ),
        'author' => 
        array (
          'id' => '1',
          'name' => '牟佳斌',
          'avatar' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/b9d/dfd/a54/49d/d64/892/f2d/7cd/5e8/198/28.jpg_200_200_2_a810.jpg',
        ),
        'publishedTime' => 1473331564,
        'isFavorite' => false,
        'isLike' => false,
        'commentNum' => 0,
        'url' => '',
        'comments' => 
        array (
        ),
        'udid' => '1',
        'isRecommend' => true,
        'isEditable' => false,
        'canShare' => false,
        'sp' => 
        array (
          0 => 
          array (
            'id' => 28,
            'title' => '海淘大集合',
            'imageUrl' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/082/aad/b33/09f/e58/568/90f/b37/c66/28b/5e.jpg_600_0_15_c488.jpg',
            'buyUrl' => 'http://ym.zdmimg.com/201511/16/5649d2ec6a96f8609.png_e600.jpg',
            'storeName' => '淘宝商家',
            'price' => '222',
          ),
        ),
        'shareUserCount' => 0,
      ),
      5 => 
      array (
        'id' => 56,
        'title' => '海淘入门攻略 2016版 买遍全球真的没有那么难！',
        'description' => '<p>海淘最初的定义是国内顾客从海外商城购物并运送到国内收货地址，作为国内最早引入海淘概念的网站， 从2010年什么值得买发布首条海淘信息以来，我们和值友们一起经历着海淘从一种小众的购物形式变得大众化、多样化，海淘的定义也越来越宽泛，甚至有可能 你在不知不觉中已经体验过了海淘，而海淘的原因也已经从最初的追求性价比为主，逐渐转变到追寻品质口碑商品和个性化购物上，国内跨境购物的市场规模也已经扩大的万亿元级别，并且还在以每年30%的速度递增。而各种商城也在不断推出便于海淘的服务，降低海淘门槛，现在，不懂外语、没有信用卡等等因素都不再是阻挡海淘的障碍了。</p>
<p><br />现在海淘从购物流程上面来讲，主要可以分为三种形式，第一是传统转运模式，需要将国外电商的货物通过转运公司运送到国内；第二种是直邮模式，外国电商可以直接将商品寄往中国境内；第三种是近两年新兴起来的模式，增长非常迅速，也吸引了不少没有海淘经验的网友试水，那就是跨境电商，主要指国内电商从国外仓库或国内的保税区仓库发货给顾客，由于也需要经过海关清关等入境过程，所以也划分到海淘。</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<p style="font-size: 14px; border-left: none; padding-left: 0px; margin-top: 0px; margin-bottom: 0px;">这三类海淘形式各有优势和缺点，下面就从易到难，在整体流程的角度，为值友们一一介绍，大家可以从实际情况入手，选择不同海淘方式：</p>
<p style="font-size: 14px; border-left: none; padding-left: 0px; margin-top: 0px; margin-bottom: 0px;">基本流程<br />不论是转运、跨境还是直邮，购物之后的支付都是必须的过程，在国外网站购物需使用当地货币支付，因此最好能准备一张双币种或多币种信用卡，可以节约货币转换费，如何选择海淘信用卡？可以参考此篇攻略。</p>
</blockquote>
<p>不过，信用卡申请有一定的门槛，如果没有信用卡是不是就不能海淘了呢？不是！</p>
<p>现在已经有越来越多的外国商城和跨境电商支持支付宝、财付通、银联支付等付款方式，例如西集网、日本乐天、英国的美妆商城lookfantastic、美国的macy&rsquo;s 梅西百货等等，而且这些海淘低门槛电商也在不断增加中。</p>
<p>准备好支付工具之后，就可以根据自身的实际情况和需求去选择购物商城和海淘方式了</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/1e0/621/53d/9bc/e56/fb4/f5f/03f/a75/849/b8.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>&nbsp;</p>',
        'image' => 
        array (
          'url' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/1c2/827/215/fef/8bb/058/806/f6c/b93/1ba/a1.jpg_600_0_15_40b3.jpg',
        ),
        'images' => 
        array (
          0 => 
          array (
            'url' => 'http://fsvr.dealmoon.com/dealmoon/1e0/621/53d/9bc/e56/fb4/f5f/03f/a75/849/b8.jpg',
          ),
        ),
        'category' => 
        array (
          'id' => 53,
          'nameCh' => '时尚11',
        ),
        'author' => 
        array (
          'id' => '1',
          'name' => '牟佳斌',
          'avatar' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/b9d/dfd/a54/49d/d64/892/f2d/7cd/5e8/198/28.jpg_200_200_2_a810.jpg',
        ),
        'publishedTime' => 1473327471,
        'isFavorite' => false,
        'isLike' => false,
        'commentNum' => 0,
        'url' => '',
        'comments' => 
        array (
        ),
        'udid' => '1',
        'isRecommend' => false,
        'isEditable' => false,
        'canShare' => false,
        'sp' => 
        array (
        ),
        'shareUserCount' => 0,
      ),
      6 => 
      array (
        'id' => 59,
        'title' => '2016年新版海淘攻略：在线钻石零售商 Blue Nile 直邮 购物教程',
        'description' => '<p>钻石已经成为不少人的人生刚需，婚礼必备之物，国内钻石价格昂贵，那么有没有其他的途径可以购买呢？经常关注我站海淘频道的值友们对Blue Nile一定不陌生，Blue Nile是一家支持全程直邮运输保险、全中文页面的钻石商城，什么值得买（SMZDM.COM）在2015年推出过Blue Nile购物攻略，目前商家信息略有改动，小编在此更新2016年最新版，主要更新的内容有：支付方式、自提信息、直邮信息、运输周期、商家客服联系方式等。更多详情请值友们滚动小鼠标，往下查看~</p>
<p>Blue Nile我站推荐过多次，作为全球最大的钻石在线销售商，Blue Nile十年前就已经在纳斯达克上市，其最大优势在于超过二十万颗的裸钻钻石库，所有钻石都提供GIA证书，相比品牌钻饰，购买裸钻然后自行找工匠镶嵌，总体花费成本性价比十分高，同时Blue Nile也提供其他珠宝，并联合国际顶级设计师推出设计师系列珠宝。</p>
<p>我站已经有不少值友在原创频道分享过从Blue Nile海淘钻石的璀璨成果，同时也有关于如何选购钻石和海淘钻石的经验，这篇Blue Nile的购物教程，将从钻石筛选、购买、付款等多方面展示Blue Nile的购物流程，希望对值友们有所帮助。</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<h2 style="color: #000000; font-size: 18px; border-left: none; padding-left: 0px; margin-bottom: 10px; margin-top: 10px;"><strong>一.注册账户及Blue Nile首页概览</strong></h2>
</blockquote>
<p>1.Blue Nile中文官网&nbsp;<br />打开首页，Blue Nile对于海淘十分友好，官网会根据使用者的IP地址进行自动定位，并转换为该国的文字，并且中文官网翻译十分全面，包括钻石的介绍都是全中文，使用起来还是十分方便的。如果跳转到了香港或美国官网，手动在页面右上角选择国旗和货币就可以切换了。</p>
<p><br />这里需要注意的是， 同样的钻石，美国官网和中文官网的价格会有所区别，这是因为中文官网在页面上显示的价格，是已经计算好的商品从美国直邮中国的含税到手价，而美国官网显示 的价格虽然不包含直邮关税，但是实际上使用直邮方式购买的时候，在结算的时候还是会算入税费，所以这篇攻略仍旧以购买更友好的中文官网为介绍对象，而且即 便上加上关税，同类型的钻石在Blue Nile的价格仍比国内有较大优势。</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<h2 style="color: #000000; font-size: 18px; border-left: none; padding-left: 0px; margin-bottom: 10px; margin-top: 10px;">2.注册Blue Nile账号。</h2>
</blockquote>
<p>点击首页右上角的&ldquo;登录&rdquo;链接即可进入登录或注册账号页面，在该页面左侧可以看到创建账户入口，点击之后，按照页面中文说明填写资料即可，最后再点击&ldquo;创建账户&rdquo;就完成注册了。</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473329084811"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103267" data-dom-id="usg_1032671473329085885"><a href="http://www.dealmoon.com/post/103267?ck=23785752d9befebaafc237b27e3d671d" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/0a6/26b/d2a/997/9c2/a28/88d/02e/5ba/00c/ef.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/683/894/529/11d/6f0/134/bbc/86c/7b5/74c/de.jpg_200_200_2_ada2.jpg" /><span class="user-name">shibasamon</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">我们家的萌宠?</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block dm_external_goods" contenteditable="false" data-type="external_product" data-pro_img_url="http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/04a/9c6/400/e99/908/b72/ae8/419/3c5/537/5f.jpg_600_0_15_4e66.jpg" data-pro_business="淘宝dealmoon专卖" data-pro_title="中秋节大礼包" data-pro_price="222" data-pro_links="http://adm.dealmoon.com" data-id="29"><img class="pro_img" src="http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/04a/9c6/400/e99/908/b72/ae8/419/3c5/537/5f.jpg_600_0_15_4e66.jpg" />
<div class="pro_content">
<p class="business">淘宝dealmoon专卖</p>
<p class="content">中秋节大礼包</p>
<p class="price">222</p>
</div>
<a class="pro_buy" contenteditable="false" href="http://adm.dealmoon.com" target="_blank">购买</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/3b7/424/832/f1f/686/f64/659/817/ca3/c34/23.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p class="dm_split">&nbsp; &nbsp;</p>',
        'image' => 
        array (
          'url' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/f32/899/baa/804/38c/2b6/932/15f/a7f/71f/c1.jpg_600_0_15_ad11.jpg',
        ),
        'images' => 
        array (
          0 => 
          array (
            'url' => 'http://fsvr.dealmoon.com/dealmoon/3b7/424/832/f1f/686/f64/659/817/ca3/c34/23.jpg',
          ),
        ),
        'category' => 
        array (
          'id' => 53,
          'nameCh' => '时尚11',
        ),
        'author' => 
        array (
          'id' => '1',
          'name' => '牟佳斌',
          'avatar' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/b9d/dfd/a54/49d/d64/892/f2d/7cd/5e8/198/28.jpg_200_200_2_a810.jpg',
        ),
        'publishedTime' => 1473329193,
        'isFavorite' => false,
        'isLike' => false,
        'commentNum' => 0,
        'url' => '',
        'comments' => 
        array (
        ),
        'udid' => '1',
        'isRecommend' => false,
        'isEditable' => false,
        'canShare' => false,
        'sp' => 
        array (
          0 => 
          array (
            'id' => 29,
            'title' => '中秋节大礼包',
            'imageUrl' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/04a/9c6/400/e99/908/b72/ae8/419/3c5/537/5f.jpg_600_0_15_4e66.jpg',
            'buyUrl' => 'http://adm.dealmoon.com',
            'storeName' => '淘宝dealmoon专卖',
            'price' => '222',
          ),
        ),
        'shareUserCount' => 0,
      ),
    ),
  ),
)

array (
  'categoriesGuides' => 
  array (
    0 => 
    array (
      'id' => 60,
      'articleType' => 
      array (
        0 => 
        array (
          'id' => 18,
          'desc' => '秘籍',
        ),
      ),
      'category' => 
      array (
        0 => 
        array (
          'id' => 53,
          'desc' => '时尚11',
          'level' => 1,
        ),
        1 => 
        array (
          'id' => 54,
          'desc' => '海淘',
          'level' => 1,
        ),
        2 => 
        array (
          'id' => 57,
          'desc' => '内衣',
          'level' => 2,
        ),
        3 => 
        array (
          'id' => 61,
          'desc' => '亲子教育',
          'level' => 2,
        ),
      ),
      'title' => '《值客说》第43期：英镑跌到8块8， 拔草英淘好时机！英淘攻略&好物都在这儿了',
      'postImgUrl' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/692/fea/73f/76c/0c1/32f/a43/9c4/2c4/db7/10.jpg_600_0_15_d154.jpg',
      'content' => '<p>6月24日，我们还在看独立日的时候英国脱欧啦！感觉好莱坞早已看透一切呢~小小MOON只想带个小喇叭 告诉大家：大不列颠，大不列颠，及北爱尔兰联合王国脱欧了!&nbsp;原价都是9.8,9.7,9.6的英镑，现在通通8.8，通通8.8，再不英淘就是亏！本期 DEALMOON说汇集了英淘方方面面的知识，从购物攻略到好物推荐，长草英淘的话现在可是下手好时机~</p>
<p>海淘淘得好来当生活家！还不知道什么是&ldquo;生活家&rdquo;的值友看这里，俗话说世事洞明皆学问，处处都有老司机。只有愿意用心感受生活、发现生活，每个人都可能是独当一面的&ldquo;生活家&rdquo;。欢迎大家积极加入什么值得买生活家阵营，传授你的独家经验。</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473329528961"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<p class="dm_split">&nbsp;</p>',
      'affiliateTags' => 
      array (
      ),
      'brandTags' => 
      array (
      ),
      'publishNotes' => 
      array (
      ),
      'author' => 
      array (
        'id' => 1,
        'img' => '',
        'name' => 'xliu',
      ),
      'items' => 
      array (
        0 => 
        array (
          'id' => 103268,
          'type' => 1,
          'desc' => 'post',
        ),
      ),
      'top' => 0,
      'recommend' => 1,
      'state' => 
      array (
        'id' => 30,
        'desc' => '已发布',
      ),
      'publishDate' => '2016-09-08 03:50:13',
      'modifyDate' => '2016-09-08 04:09:00',
      'createDate' => '2016-09-08 03:14:35',
      'statistic' => 
      array (
        'commentNum' => 0,
      ),
      'commentDisabled' => 0,
      'images' => 
      array (
      ),
    ),
    1 => 
    array (
      'id' => 59,
      'articleType' => 
      array (
        0 => 
        array (
          'id' => 19,
          'desc' => '教材',
        ),
      ),
      'category' => 
      array (
        0 => 
        array (
          'id' => 53,
          'desc' => '时尚11',
          'level' => 1,
        ),
        1 => 
        array (
          'id' => 58,
          'desc' => '袜子',
          'level' => 2,
        ),
        2 => 
        array (
          'id' => 60,
          'desc' => '职业装',
          'level' => 2,
        ),
      ),
      'title' => '2016年新版海淘攻略：在线钻石零售商 Blue Nile 直邮 购物教程',
      'postImgUrl' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/f32/899/baa/804/38c/2b6/932/15f/a7f/71f/c1.jpg_600_0_15_ad11.jpg',
      'content' => '<p>钻石已经成为不少人的人生刚需，婚礼必备之物，国内钻石价格昂贵，那么有没有其他的途径可以购买呢？经常关注我站海淘频道的值友们对Blue Nile一定不陌生，Blue Nile是一家支持全程直邮运输保险、全中文页面的钻石商城，什么值得买（SMZDM.COM）在2015年推出过Blue Nile购物攻略，目前商家信息略有改动，小编在此更新2016年最新版，主要更新的内容有：支付方式、自提信息、直邮信息、运输周期、商家客服联系方式等。更多详情请值友们滚动小鼠标，往下查看~</p>
<p>Blue Nile我站推荐过多次，作为全球最大的钻石在线销售商，Blue Nile十年前就已经在纳斯达克上市，其最大优势在于超过二十万颗的裸钻钻石库，所有钻石都提供GIA证书，相比品牌钻饰，购买裸钻然后自行找工匠镶嵌，总体花费成本性价比十分高，同时Blue Nile也提供其他珠宝，并联合国际顶级设计师推出设计师系列珠宝。</p>
<p>我站已经有不少值友在原创频道分享过从Blue Nile海淘钻石的璀璨成果，同时也有关于如何选购钻石和海淘钻石的经验，这篇Blue Nile的购物教程，将从钻石筛选、购买、付款等多方面展示Blue Nile的购物流程，希望对值友们有所帮助。</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<h2 style="color: #000000; font-size: 18px; border-left: none; padding-left: 0px; margin-bottom: 10px; margin-top: 10px;"><strong>一.注册账户及Blue Nile首页概览</strong></h2>
</blockquote>
<p>1.Blue Nile中文官网&nbsp;<br />打开首页，Blue Nile对于海淘十分友好，官网会根据使用者的IP地址进行自动定位，并转换为该国的文字，并且中文官网翻译十分全面，包括钻石的介绍都是全中文，使用起来还是十分方便的。如果跳转到了香港或美国官网，手动在页面右上角选择国旗和货币就可以切换了。</p>
<p><br />这里需要注意的是， 同样的钻石，美国官网和中文官网的价格会有所区别，这是因为中文官网在页面上显示的价格，是已经计算好的商品从美国直邮中国的含税到手价，而美国官网显示 的价格虽然不包含直邮关税，但是实际上使用直邮方式购买的时候，在结算的时候还是会算入税费，所以这篇攻略仍旧以购买更友好的中文官网为介绍对象，而且即 便上加上关税，同类型的钻石在Blue Nile的价格仍比国内有较大优势。</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<h2 style="color: #000000; font-size: 18px; border-left: none; padding-left: 0px; margin-bottom: 10px; margin-top: 10px;">2.注册Blue Nile账号。</h2>
</blockquote>
<p>点击首页右上角的&ldquo;登录&rdquo;链接即可进入登录或注册账号页面，在该页面左侧可以看到创建账户入口，点击之后，按照页面中文说明填写资料即可，最后再点击&ldquo;创建账户&rdquo;就完成注册了。</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473329084811"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103267" data-dom-id="usg_1032671473329085885"><a href="http://www.dealmoon.com/post/103267?ck=23785752d9befebaafc237b27e3d671d" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/0a6/26b/d2a/997/9c2/a28/88d/02e/5ba/00c/ef.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/683/894/529/11d/6f0/134/bbc/86c/7b5/74c/de.jpg_200_200_2_ada2.jpg" /><span class="user-name">shibasamon</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">我们家的萌宠?</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block dm_external_goods" contenteditable="false" data-type="external_product" data-pro_img_url="http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/04a/9c6/400/e99/908/b72/ae8/419/3c5/537/5f.jpg_600_0_15_4e66.jpg" data-pro_business="淘宝dealmoon专卖" data-pro_title="中秋节大礼包" data-pro_price="222" data-pro_links="http://adm.dealmoon.com" data-id="29"><img class="pro_img" src="http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/04a/9c6/400/e99/908/b72/ae8/419/3c5/537/5f.jpg_600_0_15_4e66.jpg" />
<div class="pro_content">
<p class="business">淘宝dealmoon专卖</p>
<p class="content">中秋节大礼包</p>
<p class="price">222</p>
</div>
<a class="pro_buy" contenteditable="false" href="http://adm.dealmoon.com" target="_blank">购买</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/3b7/424/832/f1f/686/f64/659/817/ca3/c34/23.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p class="dm_split">&nbsp; &nbsp;</p>',
      'affiliateTags' => 
      array (
        0 => 
        array (
          'id' => 5,
          'desc' => '1-800-FLORALS',
        ),
        1 => 
        array (
          'id' => 2549,
          'desc' => '3.1 Phillip Lim',
        ),
        2 => 
        array (
          'id' => 1621,
          'desc' => '4InkJets',
        ),
        3 => 
        array (
          'id' => 2106,
          'desc' => 'Saks Off 5th',
        ),
      ),
      'brandTags' => 
      array (
        0 => 
        array (
          'id' => 386,
          'desc' => '7 For All Mankind',
        ),
      ),
      'publishNotes' => 
      array (
      ),
      'author' => 
      array (
        'id' => 1,
        'img' => '',
        'name' => 'xliu',
      ),
      'items' => 
      array (
        0 => 
        array (
          'id' => 103268,
          'type' => 1,
          'desc' => 'post',
        ),
        1 => 
        array (
          'id' => 103267,
          'type' => 1,
          'desc' => 'post',
        ),
        2 => 
        array (
          'id' => 29,
          'type' => 3,
          'desc' => 'product',
        ),
      ),
      'top' => 0,
      'recommend' => 0,
      'state' => 
      array (
        'id' => 20,
        'desc' => '待发布',
      ),
      'modifyDate' => '2016-09-08 03:17:13',
      'createDate' => '2016-09-08 03:06:33',
      'statistic' => 
      array (
        'commentNum' => 0,
      ),
      'commentDisabled' => 0,
      'images' => 
      array (
        0 => 
        array (
          'id' => 22,
          'userGuideId' => 59,
          'userId' => 1,
          'userType' => 1,
          'img' => 'http://fsvr.dealmoon.com/dealmoon/3b7/424/832/f1f/686/f64/659/817/ca3/c34/23.jpg',
        ),
      ),
    ),
    2 => 
    array (
      'id' => 57,
      'articleType' => 
      array (
        0 => 
        array (
          'id' => 21,
          'desc' => '文章',
        ),
      ),
      'category' => 
      array (
        0 => 
        array (
          'id' => 54,
          'desc' => '海淘',
          'level' => 1,
        ),
      ),
      'title' => '黑五必看：美国亚马逊 直邮服务 手把手教程 2016最新版',
      'postImgUrl' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/d8f/a74/b40/7c9/d63/d9a/b20/11d/366/1e9/0b.jpg_600_0_15_98ee.jpg',
      'content' => '<p>美国亚马逊扩大直邮业务已经快两年了，这期间相信已经有不少值友通过直邮购买过美亚商品，在什么值得买（SMZDM.COM）日常的海淘推荐中也能看到很多值友分享美亚直邮的经验及反馈，目前美亚上面可直邮商品已经覆盖了服饰鞋包、母婴保健、美妆个护、数码3C、日百等大部分内容，可以说是非常适合海淘新手第一站，老手重复光顾的海淘热门商城。</p>
<p>今年黑五临近，为了给更多的值友指引，也为了对去年的攻略进行补充修正，什么值得买（SMZDM.COM）推出直邮服务 手把手教程2016版，包含如何寻找可直邮商品、购买、支付、查询订单、咨询客服以及Prime会员服务、Gift Cards购买等相关内容，将向大家展示如何完成一次完整的直邮购物过程。</p>
<div class="dm_insert_video dm_insert_block" contenteditable="false">
<div style="position: relative;"><embed type="application/x-shockwave-flash" class="edui-faked-video" play="false" loop="false" menu="false" allowscriptaccess="true" src="http://player.youku.com/player.php/sid/XMTcxNjQyMzQ5Ng==/v.swf" width="100%" height="290px" allowfullscreen="true" pluginspage="http://www.macromedia.com/go/getflashplayer" autostart="false" wmode="transparent" data-mce-fragment="1"></embed>
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
<p>&nbsp;</p>
<p>美国亚马逊 Amazon.com 最新优惠 丨 注册Prime会员 丨 购买Gift Cards 丨 黑五专区<br />美国亚马逊&nbsp;直邮服务常见问题解答<br />如果有过美亚购物经验的值友可以跳过第一部分注册流程，从购买可直邮商品开始看。</p>
<p>如何在美国亚马逊注册新账户<br />在美亚海淘首先需要准备一张支持美元的双币、多币信用卡或者银联信用卡，可以参照本站原创频道中的海淘信用卡选择经验。</p>
<p>1.打开美亚首页，在页面顶部可以看到黑色的导航条，点击右侧&ldquo;Your Account&rdquo;你的账户下面的&ldquo;Start here&rdquo;即可进入新账户注册页面。&nbsp;</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/296/863/079/fd3/a4b/6ad/e3e/6ff/229/ace/67.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473327867654"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103267" data-dom-id="usg_1032671473327868613"><a href="http://www.dealmoon.com/post/103267?ck=23785752d9befebaafc237b27e3d671d" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/0a6/26b/d2a/997/9c2/a28/88d/02e/5ba/00c/ef.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/683/894/529/11d/6f0/134/bbc/86c/7b5/74c/de.jpg_200_200_2_ada2.jpg" /><span class="user-name">shibasamon</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">我们家的萌宠?</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block dm_external_goods" contenteditable="false" data-type="external_product" data-pro_img_url="http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/082/aad/b33/09f/e58/568/90f/b37/c66/28b/5e.jpg_600_0_15_c488.jpg" data-pro_business="淘宝商家" data-pro_title="海淘大集合" data-pro_price="222" data-pro_links="http://ym.zdmimg.com/201511/16/5649d2ec6a96f8609.png_e600.jpg" data-id="28"><img class="pro_img" src="http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/082/aad/b33/09f/e58/568/90f/b37/c66/28b/5e.jpg_600_0_15_c488.jpg" />
<div class="pro_content">
<p class="business">淘宝商家</p>
<p class="content">海淘大集合</p>
<p class="price">222</p>
</div>
<a class="pro_buy" contenteditable="false" href="http://ym.zdmimg.com/201511/16/5649d2ec6a96f8609.png_e600.jpg" target="_blank">购买</a></div>
<p class="dm_split">&nbsp;</p>
<p class="dm_split">2. &nbsp; 填写注册信息。在新账户注册页面可以看到十分简洁的信息栏，按照下图中的注释填写信息即可，需注意，姓名需按照中文语序填写拼音即可，比如张大妈，就填写&ldquo;ZHANG DA MA&rdquo;，而不要写成&ldquo;DA MA ZHANG&rdquo;，填写完成后点击下方的&ldquo;Create your Amazon account&rdquo;即可创建新账户。</p>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/ab7/c5a/d54/dd5/748/f42/2cc/6fe/246/4de/ae.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p class="dm_split">&nbsp;</p>
<p><strong>完善个人信息</strong></p>
<p><br />不管是使用直邮服务还是通过转运购买，都建议在注册完新账户之后立刻完善自己的个人信息，包括收货地址、支付信息等，美亚会依据这些信息而将商品页面部分信息作出调整，方便选购，比如如果默认地址设置为中国，商品页面会自动显示这个商品是否能够直邮中国。</p>
<p>设置收货地址。点击导航条右侧的&ldquo;Your Account&rdquo;你的账户，进入账户信息页面，如下图所示，这个页面中可以看到Orders&nbsp;历史订单、Amazon Wallet&nbsp;支付信息、Settings&nbsp;账户设置等内容。</p>',
      'affiliateTags' => 
      array (
        0 => 
        array (
          'id' => 4,
          'desc' => '1-800-Baskets.com',
        ),
        1 => 
        array (
          'id' => 2549,
          'desc' => '3.1 Phillip Lim',
        ),
        2 => 
        array (
          'id' => 1621,
          'desc' => '4InkJets',
        ),
        3 => 
        array (
          'id' => 303,
          'desc' => 'Fashion58',
        ),
      ),
      'brandTags' => 
      array (
        0 => 
        array (
          'id' => 2593,
          'desc' => 'Twelfth St. By Cynthia Vincent',
        ),
        1 => 
        array (
          'id' => 2594,
          'desc' => 'Twinkle',
        ),
      ),
      'publishNotes' => 
      array (
      ),
      'author' => 
      array (
        'id' => 1,
        'img' => '',
        'name' => 'xliu',
      ),
      'items' => 
      array (
        0 => 
        array (
          'id' => 103268,
          'type' => 1,
          'desc' => 'post',
        ),
        1 => 
        array (
          'id' => 103267,
          'type' => 1,
          'desc' => 'post',
        ),
        2 => 
        array (
          'id' => 28,
          'type' => 3,
          'desc' => 'product',
        ),
      ),
      'top' => 0,
      'recommend' => 1,
      'state' => 
      array (
        'id' => 30,
        'desc' => '已发布',
      ),
      'publishDate' => '2016-09-08 03:46:04',
      'modifyDate' => '2016-09-12 03:37:34',
      'createDate' => '2016-09-08 02:46:45',
      'statistic' => 
      array (
        'commentNum' => 0,
      ),
      'commentDisabled' => 0,
      'images' => 
      array (
        0 => 
        array (
          'id' => 20,
          'userGuideId' => 57,
          'userId' => 1,
          'userType' => 1,
          'img' => 'http://fsvr.dealmoon.com/dealmoon/296/863/079/fd3/a4b/6ad/e3e/6ff/229/ace/67.jpg',
        ),
        1 => 
        array (
          'id' => 21,
          'userGuideId' => 57,
          'userId' => 1,
          'userType' => 1,
          'img' => 'http://fsvr.dealmoon.com/dealmoon/ab7/c5a/d54/dd5/748/f42/2cc/6fe/246/4de/ae.jpg',
        ),
      ),
    ),
    3 => 
    array (
      'id' => 56,
      'articleType' => 
      array (
        0 => 
        array (
          'id' => 20,
          'desc' => '视频',
        ),
      ),
      'category' => 
      array (
        0 => 
        array (
          'id' => 53,
          'desc' => '时尚11',
          'level' => 1,
        ),
        1 => 
        array (
          'id' => 54,
          'desc' => '海淘',
          'level' => 1,
        ),
        2 => 
        array (
          'id' => 58,
          'desc' => '袜子',
          'level' => 2,
        ),
        3 => 
        array (
          'id' => 62,
          'desc' => '海外奶粉',
          'level' => 2,
        ),
      ),
      'title' => '海淘入门攻略 2016版 买遍全球真的没有那么难！',
      'postImgUrl' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/1c2/827/215/fef/8bb/058/806/f6c/b93/1ba/a1.jpg_600_0_15_40b3.jpg',
      'content' => '<p>海淘最初的定义是国内顾客从海外商城购物并运送到国内收货地址，作为国内最早引入海淘概念的网站， 从2010年什么值得买发布首条海淘信息以来，我们和值友们一起经历着海淘从一种小众的购物形式变得大众化、多样化，海淘的定义也越来越宽泛，甚至有可能 你在不知不觉中已经体验过了海淘，而海淘的原因也已经从最初的追求性价比为主，逐渐转变到追寻品质口碑商品和个性化购物上，国内跨境购物的市场规模也已经扩大的万亿元级别，并且还在以每年30%的速度递增。而各种商城也在不断推出便于海淘的服务，降低海淘门槛，现在，不懂外语、没有信用卡等等因素都不再是阻挡海淘的障碍了。</p>
<p><br />现在海淘从购物流程上面来讲，主要可以分为三种形式，第一是传统转运模式，需要将国外电商的货物通过转运公司运送到国内；第二种是直邮模式，外国电商可以直接将商品寄往中国境内；第三种是近两年新兴起来的模式，增长非常迅速，也吸引了不少没有海淘经验的网友试水，那就是跨境电商，主要指国内电商从国外仓库或国内的保税区仓库发货给顾客，由于也需要经过海关清关等入境过程，所以也划分到海淘。</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<p style="font-size: 14px; border-left: none; padding-left: 0px; margin-top: 0px; margin-bottom: 0px;">这三类海淘形式各有优势和缺点，下面就从易到难，在整体流程的角度，为值友们一一介绍，大家可以从实际情况入手，选择不同海淘方式：</p>
<p style="font-size: 14px; border-left: none; padding-left: 0px; margin-top: 0px; margin-bottom: 0px;">基本流程<br />不论是转运、跨境还是直邮，购物之后的支付都是必须的过程，在国外网站购物需使用当地货币支付，因此最好能准备一张双币种或多币种信用卡，可以节约货币转换费，如何选择海淘信用卡？可以参考此篇攻略。</p>
</blockquote>
<p>不过，信用卡申请有一定的门槛，如果没有信用卡是不是就不能海淘了呢？不是！</p>
<p>现在已经有越来越多的外国商城和跨境电商支持支付宝、财付通、银联支付等付款方式，例如西集网、日本乐天、英国的美妆商城lookfantastic、美国的macy&rsquo;s 梅西百货等等，而且这些海淘低门槛电商也在不断增加中。</p>
<p>准备好支付工具之后，就可以根据自身的实际情况和需求去选择购物商城和海淘方式了</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/1e0/621/53d/9bc/e56/fb4/f5f/03f/a75/849/b8.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>&nbsp;</p>',
      'affiliateTags' => 
      array (
      ),
      'brandTags' => 
      array (
      ),
      'publishNotes' => 
      array (
      ),
      'author' => 
      array (
        'id' => 1,
        'img' => '',
        'name' => 'xliu',
      ),
      'top' => 0,
      'recommend' => 0,
      'state' => 
      array (
        'id' => 10,
        'desc' => '草稿箱',
      ),
      'modifyDate' => '2016-09-08 02:40:13',
      'createDate' => '2016-09-08 02:37:51',
      'statistic' => 
      array (
        'commentNum' => 0,
      ),
      'commentDisabled' => 0,
      'images' => 
      array (
        0 => 
        array (
          'id' => 19,
          'userGuideId' => 56,
          'userId' => 1,
          'userType' => 1,
          'img' => 'http://fsvr.dealmoon.com/dealmoon/1e0/621/53d/9bc/e56/fb4/f5f/03f/a75/849/b8.jpg',
        ),
      ),
    ),
    4 => 
    array (
      'id' => 55,
      'articleType' => 
      array (
        0 => 
        array (
          'id' => 18,
          'desc' => '秘籍',
        ),
      ),
      'category' => 
      array (
        0 => 
        array (
          'id' => 63,
          'desc' => '海外尿不湿',
          'level' => 2,
        ),
      ),
      'title' => '英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记',
      'postImgUrl' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/593/2c9/c79/914/8ae/394/b60/37f/256/a8a/3b.jpg_600_0_15_f2ae.jpg',
      'content' => '<p>英国脱欧之后，本宝宝坐等汇率下跌，心情澎拜，赶脚不买点什么就对不起卡梅伦了</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/edf/82e/4c3/534/a09/4fa/ca0/7a3/f11/871/ce.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn" style="display: none;">注释</button></div>
</div>
<div class="dm_comment mceEditable">这是英国首相&nbsp;</div>
</div>
</div>
<p>&nbsp;正好我家小子马上转口粮，1+转2+，原来一直在德国买（说的好像去过德国一样英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记 ），爱他美咩，地球人都知道，之前吃喜宝的，但是后来基本买不到了，国人确实厉害英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记 转战英国必须买牛栏啊，好歹在作为母婴之友的资深奶爸还是做了功课的。于是直奔牛栏大英帝国官网</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/842/3e5/5f2/c10/a73/347/ac3/c10/1bc/846/4f.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>到红框框里画的没，都可以买，相当于是牛栏英国官方指定购买地址，内心是比较放心的。于是乎开始度娘这几个站，TESCO和BOOTS可能值友们相对熟悉一些（连我都知道英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记 ），点卡差不多都是8英镑一盒，算上8.9的汇率基本上70来块钱吧，大英帝国的人民真幸福啊英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记 ，当我在比较的时候发现OCADO有个重大优惠：新客满80磅立减20磅！！长期混张大妈的都懂！那就是从它下手吧！</p>
<p>做完准备工作那就开始买买买吧，购物流程很简单，不过为了大家更直观，还是简单说下，会点鸟语的或者海淘小能手可以略过英国大型B2C零售商 Ocado 奥凯多 牛栏奶粉购买记。</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473326778912"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103267" data-dom-id="usg_1032671473326780204"><a href="http://www.dealmoon.com/post/103267?ck=23785752d9befebaafc237b27e3d671d" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/0a6/26b/d2a/997/9c2/a28/88d/02e/5ba/00c/ef.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://imgcache.dealmoon.com/fsvr.dealmoon.com/avatar/683/894/529/11d/6f0/134/bbc/86c/7b5/74c/de.jpg_200_200_2_ada2.jpg" /><span class="user-name">shibasamon</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">我们家的萌宠?</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473326781331"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473326782843"><a href="http://www.dealmoon.com/post/103268?ck=f3d2364278c14b15301f958af53bc801" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split">&nbsp;</p>
<p>4、点击右上角cheakout去结算，基本跟亚马逊什么的类似，相对还是比较好操作的,依次填写 送货地址、日期（可以精确到时间段，建议上班时间送，毕竟大家走的都是转运）、付款信息（支持国卡，不支持银联），最后确认无误就下单，只要是工作日第二 天就能到转运仓库了。注意的是要收2英镑的税、打包盒运费，总共扣款是62英镑。</p>
<p><br />&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;&mdash;我&mdash;&mdash;&mdash;&mdash;是&mdash;&mdash;&mdash;&mdash;邪&mdash;&mdash;&mdash;&mdash;恶&mdash;&mdash;&mdash;的&mdash;&mdash;&mdash;&mdash;分&mdash;&mdash;&mdash;隔&mdash;&mdash;&mdash;&mdash;线&mdash;&mdash;&mdash;</p>
<p>下面就到转运了，具体流程自行搜索吧。</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<h2 style="color: #000000; font-size: 18px; border-left: none; padding-left: 0px; margin-bottom: 10px; margin-top: 10px;">中间有个小插曲，货送到仓库两天没入库，就咨询了下，结果告知没有外包装，也就说没有外面的大盒子 &nbsp; &nbsp;好吧，转运提交的时候价格固，20块，嗯还比较便宜，加上某转运做活动，全场6.28折（大家都懂的），10盒运费加上加固一共花了255.34，1个礼拜到手，还是挺不错了。</h2>
</blockquote>
<p>中间被税了，这是预料之中的，没被退运，已经很满足啦 &nbsp; &nbsp;</p>',
      'affiliateTags' => 
      array (
        0 => 
        array (
          'id' => 6,
          'desc' => '1-800-Flowers.com',
        ),
        1 => 
        array (
          'id' => 1973,
          'desc' => '123Print',
        ),
        2 => 
        array (
          'id' => 1469,
          'desc' => '3lab',
        ),
      ),
      'brandTags' => 
      array (
        0 => 
        array (
          'id' => 71,
          'desc' => 'Forever21',
        ),
        1 => 
        array (
          'id' => 10015,
          'desc' => '3CE',
        ),
      ),
      'publishNotes' => 
      array (
      ),
      'author' => 
      array (
        'id' => 1,
        'img' => '',
        'name' => 'xliu',
      ),
      'items' => 
      array (
        0 => 
        array (
          'id' => 103268,
          'type' => 1,
          'desc' => 'post',
        ),
        1 => 
        array (
          'id' => 103267,
          'type' => 1,
          'desc' => 'post',
        ),
        2 => 
        array (
          'id' => 103268,
          'type' => 1,
          'desc' => 'post',
        ),
        3 => 
        array (
          'id' => 103268,
          'type' => 1,
          'desc' => 'post',
        ),
      ),
      'top' => 0,
      'recommend' => 1,
      'state' => 
      array (
        'id' => 30,
        'desc' => '已发布',
      ),
      'publishDate' => '2016-09-08 03:46:14',
      'modifyDate' => '2016-09-08 04:07:32',
      'createDate' => '2016-09-08 02:27:14',
      'statistic' => 
      array (
        'commentNum' => 0,
        'likeNum' => 500,
      ),
      'commentDisabled' => 0,
      'images' => 
      array (
        0 => 
        array (
          'id' => 17,
          'userGuideId' => 55,
          'userId' => 1,
          'userType' => 1,
          'img' => 'http://fsvr.dealmoon.com/dealmoon/edf/82e/4c3/534/a09/4fa/ca0/7a3/f11/871/ce.jpg',
        ),
        1 => 
        array (
          'id' => 18,
          'userGuideId' => 55,
          'userId' => 1,
          'userType' => 1,
          'img' => 'http://fsvr.dealmoon.com/dealmoon/842/3e5/5f2/c10/a73/347/ac3/c10/1bc/846/4f.jpg',
        ),
      ),
    ),
    5 => 
    array (
      'id' => 54,
      'articleType' => 
      array (
        0 => 
        array (
          'id' => 18,
          'desc' => '秘籍',
        ),
      ),
      'category' => 
      array (
        0 => 
        array (
          'id' => 53,
          'desc' => '时尚11',
          'level' => 1,
        ),
        1 => 
        array (
          'id' => 54,
          'desc' => '海淘',
          'level' => 1,
        ),
        2 => 
        array (
          'id' => 57,
          'desc' => '内衣',
          'level' => 2,
        ),
      ),
      'title' => '2016新版：BELLE MAISON 千趣会 日本女性时尚用品商城 手把手购物攻略',
      'postImgUrl' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/04a/9c6/400/e99/908/b72/ae8/419/3c5/537/5f.jpg_600_0_15_4e66.jpg',
      'content' => '<p>Belle Maison成立于1955年，是日本千趣会旗下的电商网站，是日本知名度非常高一个购物网站，专门销售女性时尚用品，<strong>也是日本女性最常用的购物网站之一</strong>。在日本的女性中可以说是无人不晓。从女孩时代开始穿着千趣会的衣服，到女孩成为母亲，又有了自己的女儿，然后向女儿再推荐千趣会邮购服饰。千趣会就是这样一个被大众所喜爱的品牌。千趣会攻略之前于我站发布过，随着该网站在国内名气的增大，小编在上一版攻略的基础上新增了选品，形成了2016新版攻略。</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/7a6/11a/8c4/f53/9a4/f2a/58e/fc2/aa1/6ee/8c.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>浏览日本千趣会官网就会知道这是个大型网站，网站上的商品一应俱全，从妈咪宝贝用品、家居日杂、化 妆品保健品到食物甜品、男女服饰鞋包等等，通通找得到，超好逛也超好买。不过还是以服饰为主。特别宽松也是为了穿着舒服吧。颜色也复古不是特别鲜亮，以前 买过无印良品的，日系感觉都差不多，不过千趣会价格更便宜，喜欢日系风格的姑娘们可以关注此网站。Belle Maison的迪士尼系列商品、女士内衣、哺乳衣、女装、母婴用品都是网站内的人气产品。</p>
<p>千趣会已经进驻中国，在天猫开有旗舰店，但是品类较少，只经营女装和母婴用品，人气款也常常款式和号码不全，所以要买到好东西还是要深入内部啊。今天什么值得买（SMZDM.COM）带着大家走进日本千趣会，我们一起来看看怎么买，都买什么。</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/77f/496/8fa/f78/e85/c9c/1df/6d0/615/055/6b.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>&nbsp;</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<h1 style="color: #000000; font-size: 24px; line-height: 24px; padding-left: 10px; margin-top: 20px; margin-bottom: 20px; border-left: 3px solid #ff4200;"><span style="color: #d42f2f;"><strong>购买攻略</strong></span></h1>
</blockquote>
<p>千趣会目前还不能直邮，需要转运。满5000日元日本境内包邮，不满收350日元的邮费。2016年8月31日22:59（北京时间）之前注册的新用户购物日本境内免邮，另外赠1000日元的优惠券，购物满5000日元（不含税），即5400日元（税入）可使用，优惠券有效期到2016年9月13日。</p>
<p>6.选择送达时间，如果你没特别指定，括号里写着&ldquo;无料&rdquo;，也就是免费的，选一个就行。然后确认订单，他大~~一次愉快的购物就结束了，坐等收包裹就好啦。</p>
<p>以上就是日本千趣会的购买流程，这里再给大家介绍几款网站人气产品，以后什么值得买（SMZDM.COM）也会持续关注这个网站，第一时间为各位网友推荐好的单品。</p>
<p>商品推荐<br />夏季棉麻女士上衣 价格：3229日元（约人民币211元）</p>
<p><iframe id="dm_discount_541330" class="dm_insert_block dm_discount" src="index.php?r=shopping-guide/deal-preview&amp;id=541330&amp;ck=e3554a0932e9bd9eaeb203149e41d360" width="600" height="110" frameborder="none" scrolling="no" data-type="deal_discount" data-id="541330"></iframe></p>
<p class="dm_split">&nbsp;<iframe id="dm_discount_542570" class="dm_insert_block dm_discount" src="index.php?r=shopping-guide/deal-preview&amp;id=542570&amp;ck=f7b3d2bd9d3442c38a3025f61fef31d1" width="600" height="110" frameborder="none" scrolling="no" data-type="deal_discount" data-id="542570"></iframe></p>
<p class="dm_split">&nbsp;</p>
<p>Ex:beaute是在日本销售了十几年的老牌子了，深受挑剔的日本女性欢迎。女优肌，顾名思义这 款粉底液本来是给女演员使用的，随着科技发展，高清摄像机让女演员的厚重妆容一览无余。于是就出现了这款既轻薄又有一定遮盖力的底妆产品。此款粉底液对毛 孔、色素沉着等凹凸不平之处能自然遮盖，长效控油持妆。&nbsp;</p>
<p>草花木果 卸妆油 308ml 价格：2808日元（约人民币183元）</p>
<p>&nbsp;</p>',
      'affiliateTags' => 
      array (
        0 => 
        array (
          'id' => 592,
          'desc' => '1&1 Internet',
        ),
        1 => 
        array (
          'id' => 3,
          'desc' => '123Inkjets',
        ),
        2 => 
        array (
          'id' => 2549,
          'desc' => '3.1 Phillip Lim',
        ),
      ),
      'brandTags' => 
      array (
        0 => 
        array (
          'id' => 12051,
          'desc' => '14th & Union',
        ),
        1 => 
        array (
          'id' => 12423,
          'desc' => '32°HEAT',
        ),
      ),
      'publishNotes' => 
      array (
      ),
      'author' => 
      array (
        'id' => 1,
        'img' => '',
        'name' => 'xliu',
      ),
      'items' => 
      array (
        0 => 
        array (
          'id' => 541330,
          'type' => 2,
          'desc' => 'discount',
        ),
        1 => 
        array (
          'id' => 542570,
          'type' => 2,
          'desc' => 'discount',
        ),
      ),
      'top' => 0,
      'recommend' => 1,
      'state' => 
      array (
        'id' => 30,
        'desc' => '已发布',
      ),
      'publishDate' => '2016-09-08 03:46:33',
      'modifyDate' => '2016-09-08 04:09:41',
      'createDate' => '2016-09-08 02:21:19',
      'statistic' => 
      array (
        'commentNum' => 0,
      ),
      'commentDisabled' => 0,
      'images' => 
      array (
        0 => 
        array (
          'id' => 13,
          'userGuideId' => 54,
          'userId' => 1,
          'userType' => 1,
          'img' => 'http://fsvr.dealmoon.com/dealmoon/7a6/11a/8c4/f53/9a4/f2a/58e/fc2/aa1/6ee/8c.jpg',
        ),
        1 => 
        array (
          'id' => 14,
          'userGuideId' => 54,
          'userId' => 1,
          'userType' => 1,
          'img' => 'http://fsvr.dealmoon.com/dealmoon/77f/496/8fa/f78/e85/c9c/1df/6d0/615/055/6b.jpg',
        ),
      ),
    ),
    6 => 
    array (
      'id' => 53,
      'articleType' => 
      array (
        0 => 
        array (
          'id' => 18,
          'desc' => '秘籍',
        ),
      ),
      'category' => 
      array (
        0 => 
        array (
          'id' => 61,
          'desc' => '亲子教育',
          'level' => 2,
        ),
      ),
      'title' => '海淘攻略:Rakuten Global Market 乐天国际 手把手购物教程 2016最新版',
      'postImgUrl' => 'http://imgcache.dealmoon.com/fsvr.dealmoon.com/dealmoon/593/2c9/c79/914/8ae/394/b60/37f/256/a8a/3b.jpg_600_0_15_f2ae.jpg',
      'content' => '<p>乐天国际是日淘网友的主要淘货网站之一，之前站内为值友们推出过多篇乐天国际优质店铺的介绍文章，乐天市场也曾为我站提供过官方攻略，本次推出的2016年最新版购物教程，什么值得买（SMZDM.COM）对之前发布乐天国际攻略进行了更新汇总，同时增添乐天国际最新的购物流程及优质店铺，并推荐一些能让值友们的生活质量蹭蹭蹭提高的实用好物，希望能给需要的值友们带来帮助。</p>
<p>关于乐天国际<br />乐天市场（Rakuten Ichiba）连续多年在日本内销量第一，所售商品与实体店质量一致。优点是接受国际信用卡和国际派送，缺点是全日文界面，不能切换英文，不懂日语的人，要用到翻译器了。乐天国际市场（rakuten global），日本乐天的国际版，优点就是中文界面，有不少店铺现在支持银联，支付宝支付，不少商家可直邮中国，EMS从日本国内到中国一般2-3天。账号通用，在rakuten global注册一个账号可以上rakuten</p>
<div class="dm_insert_img dm_insert_block" contenteditable="false">
<div class="pos_positive">
<div style="position: relative;"><img src="http://fsvr.dealmoon.com/dealmoon/f9e/9f7/1ab/42f/8d6/2ae/2ec/806/d56/33a/c5.jpg" />
<div class="dm_edit_action" style="display: none;" contenteditable="false"><button class="btn del_btn">删除</button> <button class="btn comment_btn">注释</button></div>
</div>
<div class="dm_comment mceEditable" style="display: none;">&nbsp;</div>
</div>
</div>
<p>&nbsp; &nbsp;</p>
<p><strong>关于支付宝</strong><br />支付宝和海外商家合作，使海淘变得更加容易方便，及时是海淘小白也毫无压力。支付宝和乐天国际市场也有合作了，每周三，在特定的店铺使用支付宝支付，即可享受5%折扣优惠，同时乐天国际市场有快速使用支付宝教程供大家参考。</p>
<p><strong>注册流程</strong><br />打开Rakuten乐天国际市场的首页，点击&ldquo;注册&rdquo;，加入会员。如果不注册的话，也可以成功下单，但无法获得积分奖励。</p>
<p>1.乐天国际的注册流程已经汉化，注册十分简便。但由于中文字符易在日本系统中显示为乱码，国内地址很不标准也普遍没有标准英文翻译，请全部用拼音填写（姓名、地址）；而且EMS到了中国境内，邮递员很可能不懂英文；因此可以直接用拼音填写地址。</p>
<p>2.如果出现如下图片，就是注册成功了。接下来开始Rakuten乐天国际市场的购物之旅吧~第三步的注册会员超级简单，只需要点击最下面的&ldquo;继续使用服务&rdquo;按键即可完成。</p>
<p><br /><strong>下单流程</strong></p>
<p>乐天国际配送目前有七千余家店铺在运营，每家店铺分别接单，发货，和付款，店铺之间不能合并发货。所有中文内容都是直接从店铺的乐天市场日文网页中直接翻译过来的，部分地方会翻译得不好。网站操作流程的汉化都做得没问题，商品详情介绍的汉化就做得不够详尽，搜索商品时，时而会出现和商品信息不匹配的信息。值友们可以从乐天市场日文网页搜索商品，再更改语言设置，从而降低搜索商品的难度，此方法在这里不过过多介绍，具体操作步骤戳这里。</p>
<p>因为是全中文页面，和国内网购类似，海淘新手也无压力。</p>
<div class="dm_insert_block user_share_goods" contenteditable="false" data-type="user-share-goods" data-id="103268" data-dom-id="usg_1032681473321541175"><a href="http://www.dealmoon.com/post/103268?ck=undefined" target="_blank">
<div class="pro_img_block"><img class="pro_img" src="http://fsvrugccache.dealmoon.com/ugc/20e/6b7/834/1e1/53a/fa1/6a6/189/245/c3b/09.jpg" />
<div class="dm_edit_action" style="display: none;"><button class="btn del_btn" contenteditable="false">删除</button><button class="btn edit_btn" contenteditable="false">编辑</button></div>
</div>
<div class="pro_content">
<p class="title text_overflow" contenteditable="false"><img src="http://my.dealmoon.com/Public/images/noavatar_big1.gif" /><span class="user-name">射手座小吃货</span>&nbsp;<span class="level">Level 1</span></p>
<p class="content" contenteditable="false">送婆婆的小礼物，被老公说丑。。。叫我退掉。。。和姐妹们一起去买的，特来这里看看大家意见。各位帮帮忙，评评理吧!</p>
</div>
</a></div>
<p class="dm_split"><a id="a_1473660870553" href="http://www.amazon.com?tag=dealmoon-20">点击购买&gt;&gt;&gt;&nbsp;</a></p>
<p>2、商家发的确认邮件</p>
<p>由于目的地国家和商品包装要求的差异，无法在下单之前给出运费数额。当店铺计算好邮件的运费之后，会以邮件形式通知各项费用，确认邮件里会有所购买的商品、价格、运费、地址、支付方式等等，需要修改可以直接邮件回复，没有问题也要回复。当确认完这封邮件中的信息之后，店铺才会扣款和发货。需注意：这封邮件是必须回复的，否则店家不会发货。可以用英文回复。</p>
<p><br />谈经验：我们的网友往往难以分辨哪封是需要回复的店铺邮件。需要回复的店铺邮件有以下特点：1.邮件来自店铺的邮箱，与店铺介绍网页里给出的一致；2.邮件标题或正文中有需要回复的提醒，Please confirm或者ご確認ください的字样；3. 邮件中有运费数额，这在系统邮件中是没有的。运费的英文是shipping expenses, 日语中叫做送料。</p>
<p>3、发货邮件</p>
<p>商家会发物流信息到注册邮箱，如果是直邮商品，店铺发货之后会邮件给您EMS运单号码和EMS官网链接，点链接进去复制粘贴追踪，可以查看包裹物流信息。如果是转运商品，接下来就多多关注转运公司的情况，用转运发回国内就大功告成了，转运攻略可参考我站2016最新版日亚攻略转运部分介绍。</p>
<blockquote class="dm_blockquote dm_blockquote-right dm_blockquote-text">
<p>商家会发物流信息到注册邮箱，如果是直邮商品，店铺发货之后会邮件给您EMS运单号码和EMS官网链接，点链接进去复制粘贴追踪，可以查看包裹物流信息。如果是转运商品，接下来就多多关注转运公司的情况，用转运发回国内就大功告成了，转运攻略可参考我站2016最新版日亚攻略转运部分介绍。</p>
<p>如何选择优质商家<br />很多人一提到乐天国际就会说，可能会认为店铺众多，疑虑是否存在假货现象，购物没有保证。实际上并不然，日本在打击假货上是非常严厉的，且日本法律和乐天有关规定，只有持有日本工商执照的注册企业才能申请在乐天市场开通网店，所售商品必须和其实体店质量一致，因此大店铺还是比较放心购买的。小编接下来就给各位介绍一些乐天国际上的大卖家以及热门商品。</p>
</blockquote>
<p><iframe id="dm_discount_541330" class="dm_insert_block dm_discount" src="index.php?r=shopping-guide/deal-preview&amp;id=541330&amp;ck=undefined" width="600" height="110" frameborder="none" scrolling="no" data-type="deal_discount" data-id="541330"></iframe></p>
<p class="dm_split">&nbsp;<iframe id="dm_discount_542570" class="dm_insert_block dm_discount" src="index.php?r=shopping-guide/deal-preview&amp;id=542570&amp;ck=undefined" width="600" height="110" frameborder="none" scrolling="no" data-type="deal_discount" data-id="542570"></iframe></p>
<p class="dm_split">&nbsp;</p>',
      'affiliateTags' => 
      array (
        0 => 
        array (
          'id' => 100,
          'desc' => 'Best Buy',
        ),
        1 => 
        array (
          'id' => 592,
          'desc' => '1&1 Internet',
        ),
        2 => 
        array (
          'id' => 3,
          'desc' => '123Inkjets',
        ),
      ),
      'brandTags' => 
      array (
        0 => 
        array (
          'id' => 2592,
          'desc' => 'Tweezerman',
        ),
        1 => 
        array (
          'id' => 62,
          'desc' => 'Salvatore Ferragamo',
        ),
      ),
      'publishNotes' => 
      array (
      ),
      'author' => 
      array (
        'id' => 1,
        'img' => '',
        'name' => 'xliu',
      ),
      'items' => 
      array (
        0 => 
        array (
          'id' => 541330,
          'type' => 2,
          'desc' => 'discount',
        ),
        1 => 
        array (
          'id' => 542570,
          'type' => 2,
          'desc' => 'discount',
        ),
        2 => 
        array (
          'id' => 103268,
          'type' => 1,
          'desc' => 'post',
        ),
      ),
      'top' => 0,
      'recommend' => 1,
      'state' => 
      array (
        'id' => 30,
        'desc' => '已发布',
      ),
      'publishDate' => '2016-09-08 03:46:19',
      'modifyDate' => '2016-09-11 23:15:51',
      'createDate' => '2016-09-08 02:15:07',
      'statistic' => 
      array (
        'bookmarkNum' => 1000,
        'commentNum' => 0,
        'favorNum' => 1000,
      ),
      'commentDisabled' => 0,
      'images' => 
      array (
        0 => 
        array (
          'id' => 12,
          'userGuideId' => 53,
          'userId' => 1,
          'userType' => 1,
          'img' => 'http://fsvr.dealmoon.com/dealmoon/f9e/9f7/1ab/42f/8d6/2ae/2ec/806/d56/33a/c5.jpg',
        ),
      ),
    ),
  ),
)
array (
  'subCategory' => NULL,
)
array (
  'currentCategory' => NULL,
)
```

